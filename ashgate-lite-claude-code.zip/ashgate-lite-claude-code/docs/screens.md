# Экраны a–l

Автогенерация: `python3 tools/gen_docs.py`. **Источник истины — `docs/layout/<экран>.json`** (полное дерево узлов); ниже — читаемый конспект того же дерева.

Обозначения конспекта: `W×H @(x,y)` — размер и позиция относительно родителя; `size F/H/L` — горизонталь/вертикаль: **F**ixed, **H**ug, fi**L**l; `row|col gap … pad top right bottom left justify/align`; `bg`/`border` — токены цвета (`--color-<токен>`); `r` — радиус; `«текст» шрифт вес размер/интерлиньяж цвет`; `1 строка…` — обрезка многоточием.

## a · Первый запуск

Прокси ещё нет. Большой переключатель выключен и приглушён (opacity 0.5, `BigToggle/Off`), футер приглушён (0.5). Пилюля текущего прокси в состоянии **Empty** (пунктир 4/4, иконка вставки, чип `Ctrl+V`). Ниже — «Найдено на этом ПК»: автонайденные приложения (подпись источника «запущено» / «Пуск») с кнопкой «+». Первый запуск — **всегда светлая тема**.

- Размер: **420×640** · Figma: светлая `73:62`, тёмная `73:2437`
- Данные: [`layout/a_pervyj_zapusk.json`](layout/a_pervyj_zapusk.json) · Эталон: [`reference/screens/a_pervyj_zapusk.html`](../reference/screens/a_pervyj_zapusk.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/a_pervyj_zapusk.png) · [тёмная](../design/dark/a_pervyj_zapusk.png) · без тени: [светлая](../design/frame-only/light/a_pervyj_zapusk.png) · [тёмная](../design/frame-only/dark/a_pervyj_zapusk.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / a Первый запуск** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/Off** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 start/center · bg surface · border 1.5 strokeStrong · r 18 · opacity 0.5
      - **knob** · 24×24 · @(6.5,6) · size F/F · bg text2
    - **Headline** · 370×25 · @(24,58) · size F/H · «Пока всё идёт напрямую» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «Скопируйте ссылку прокси — и выберите приложения» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 12 pad 0 16 0 16 start/center · border 1 strokeStrong dashed · r 30 · ⟨Current proxy pill / State=Empty⟩
      - **icon/paste** · 20×20 · @(17,20) · size F/F · icon `clipboard-paste-20.svg` text2
      - **text** · 240×36 · @(49,12) · size F/H · col gap 0 pad 0 0 0 0 start/start
        - **t:Прокси ещё нет** · 108×19 · @(0,0) · size H/H · «Прокси ещё нет» Manrope 600 14/19 text
        - **t:Скопируйте ссылку — ** · 240×17 · @(0,19) · size F/H · «Скопируйте ссылку — она вставится сама» Manrope 400 12/17 text3 1 строка…
      - **Chip/Ctrl+V** · 54×20 · @(301,20) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg control · border 1 stroke · r 4
        - **t:Ctrl+V** · 40×15 · @(7,2.5) · size H/H · «Ctrl+V» Mono 500 11/15 text2
  - **Rules** · 418×378 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×18 · @(24,14) · size F/H · row gap 0 pad 0 0 0 0 start/center
      - **t:Найдено на этом ПК** · 128×18 · @(0,0) · size H/H · «Найдено на этом ПК» Manrope 600 13/18 text2
    - **Suggest/Chrome** · 370×44 · @(24,38) · size F/F · row gap 10 pad 0 6 0 12 start/center · bg surface · border 1 stroke · r 8
      - **App icon** · 24×24 · @(13,10) · size F/F · icon `app-chrome.svg` 
      - **t:Chrome** · 216×18 · @(47,13) · size F/H · «Chrome» Manrope 600 13/18 text
      - **t:запущено** · 52×15 · @(273,14.5) · size H/H · «запущено» Manrope 400 11/15 text3
      - **Button/standard** · 28×28 · @(335,8) · size F/F · row gap 8 pad 0 0 0 0 center/center · bg control · border 1 stroke · r 4
        - **icon/add** · 16×16 · @(6,6) · size F/F · icon `add-16.svg` text
    - **Suggest/Telegram** · 370×44 · @(24,88) · size F/F · row gap 10 pad 0 6 0 12 start/center · bg surface · border 1 stroke · r 8
      - **App icon** · 24×24 · @(13,10) · size F/F · icon `app-telegram.svg` 
      - **t:Telegram** · 216×18 · @(47,13) · size F/H · «Telegram» Manrope 600 13/18 text
      - **t:запущено** · 52×15 · @(273,14.5) · size H/H · «запущено» Manrope 400 11/15 text3
      - **Button/standard** · 28×28 · @(335,8) · size F/F · row gap 8 pad 0 0 0 0 center/center · bg control · border 1 stroke · r 4
        - **icon/add** · 16×16 · @(6,6) · size F/F · icon `add-16.svg` text
    - **Suggest/Dolphin Anty** · 370×44 · @(24,138) · size F/F · row gap 10 pad 0 6 0 12 start/center · bg surface · border 1 stroke · r 8
      - **App icon** · 24×24 · @(13,10) · size F/F · icon `app-dolphin-anty.svg` 
      - **t:Dolphin Anty** · 243×18 · @(47,13) · size F/H · «Dolphin Anty» Manrope 600 13/18 text
      - **t:Пуск** · 25×15 · @(300,14.5) · size H/H · «Пуск» Manrope 400 11/15 text3
      - **Button/standard** · 28×28 · @(335,8) · size F/F · row gap 8 pad 0 0 0 0 center/center · bg control · border 1 stroke · r 4
        - **icon/add** · 16×16 · @(6,6) · size F/F · icon `add-16.svg` text
    - **Suggest/Discord** · 370×44 · @(24,188) · size F/F · row gap 10 pad 0 6 0 12 start/center · bg surface · border 1 stroke · r 8
      - **App icon** · 24×24 · @(13,10) · size F/F · icon `app-discord.svg` 
      - **t:Discord** · 243×18 · @(47,13) · size F/H · «Discord» Manrope 600 13/18 text
      - **t:Пуск** · 25×15 · @(300,14.5) · size H/H · «Пуск» Manrope 400 11/15 text3
      - **Button/standard** · 28×28 · @(335,8) · size F/F · row gap 8 pad 0 0 0 0 center/center · bg control · border 1 stroke · r 4
        - **icon/add** · 16×16 · @(6,6) · size F/F · icon `add-16.svg` text
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · opacity 0.5 · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## b · Главная

Основной экран. Переключатель включён. Заголовок — одна строка («4 приложения идут через прокси»), подзаголовок — сводка статусов. Одна пилюля текущего прокси (Default). Список приложений: строки App row в состояниях Работает / Наведение (с кнопкой ⋯) / Не запущено / Ошибка (раскрыта — причина + только «Проверить снова»). Футер «Всё остальное → напрямую».

- Размер: **420×640** · Figma: светлая `73:153`, тёмная `73:2487`
- Данные: [`layout/b_glavnaya.json`](layout/b_glavnaya.json) · Эталон: [`reference/screens/b_glavnaya.html`](../reference/screens/b_glavnaya.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/b_glavnaya.png) · [тёмная](../design/dark/b_glavnaya.png) · без тени: [светлая](../design/frame-only/light/b_glavnaya.png) · [тёмная](../design/frame-only/dark/b_glavnaya.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / b Главная** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 370×25 · @(24,58) · size F/H · «4 приложения идут через прокси» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «2 работают · 1 не запущено · 1 с ошибкой» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 418×378 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×279 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 370×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
          - **text** · 221×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 221×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(277,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 370×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surfaceHover · border 1 strokeStrong · r 8 · ⟨App row / State=Наведение⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 6 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
          - **text** · 187×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Dolphin Anty** · 187×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
            - **t:↓ 860 КБ/с   ↑ 64 КБ** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(243,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
          - **Button/subtle** · 28×28 · @(334,10) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/more** · 16×16 · @(6,6) · size F/F · icon `more-vertical-16.svg` text2
      - **App row** · 370×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
          - **text** · 204×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Telegram** · 204×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
            - **t:Запустите — пойдёт ч** · 204×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/idle** · 98×24 · @(260,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
            - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
      - **App row** · 370×111 · @(0,168) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg dangerSoft · border 1 danger · r 8 · ⟨App row / State=Ошибка (раскрыта)⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-discord.svg` 
          - **text** · 230×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Discord** · 230×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text 1 строка…
            - **t:Соединения не проход** · 230×15 · @(0,20) · size F/H · «Соединения не проходят» Manrope 400 11/15 danger 1 строка…
          - **Status/err** · 72×24 · @(286,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg danger · r 12
            - **icon/error** · 12×12 · @(6,6) · size F/F · icon `error-circle-12.svg` onAccent
            - **t:Ошибка** · 42×15 · @(22,4.5) · size H/H · «Ошибка» Manrope 600 11/15 onAccent
        - **ErrorPanel** · 368×61 · @(1,49) · size F/H · col gap 8 pad 0 10 10 46 start/start
          - **t:Прокси 1 не пропуска** · 312×15 · @(46,0) · size F/H · «Прокси 1 не пропускает UDP — звонки не работают.» Manrope 400 11/15 text2
          - **Actions** · 143×28 · @(46,23) · size H/H · row gap 8 pad 0 0 0 0 start/center
            - **Retry button** · 143×28 · @(0,0) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4 · ⟨Retry button / Kind=Primary, State=Default⟩
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## c · Весь трафик

Футер в режиме «через Прокси 1» (State=Вкл, с заметкой kill switch). Заголовок одной строкой «Весь трафик → Прокси 1», подзаголовок «Все приложения Windows · SOCKS5 · Германия». Первая строка списка — выделенная **AllAppsRow** «Все приложения Windows» (accentSoft + рамка accent 1.5). Под ней заметка «Сейчас не влияет — через прокси идёт весь трафик», а пользовательские приложения — в состоянии **В тени**.

- Размер: **420×640** · Figma: светлая `73:285`, тёмная `73:2522`
- Данные: [`layout/c_ves_trafik.json`](layout/c_ves_trafik.json) · Эталон: [`reference/screens/c_ves_trafik.html`](../reference/screens/c_ves_trafik.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/c_ves_trafik.png) · [тёмная](../design/dark/c_ves_trafik.png) · без тени: [светлая](../design/frame-only/light/c_ves_trafik.png) · [тёмная](../design/frame-only/dark/c_ves_trafik.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / c Весь трафик** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 370×25 · @(24,58) · size F/H · «Весь трафик → Прокси 1» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «Все приложения Windows · SOCKS5 · Германия» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 418×354 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×240 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **AllAppsRow** · 370×51 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg accentSoft · border 1.5 accent · r 8
        - **Line** · 367×48 · @(1.5,1.5) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **OthersIcon** · 24×24 · @(12,12) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg accentSoft · r 6
            - **icon/globe** · 16×16 · @(4,4) · size F/F · icon `globe-16.svg` accentText
          - **text** · 220×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Остальные приложения** · 220×18 · @(0,0) · size F/H · «Все приложения Windows» Manrope 600 13/18 text 1 строка…
            - **t:↓ 2,1 МБ/с   ↑ 310 К** · 152×15 · @(0,20) · size H/H · «↓ 4,4 МБ/с   ↑ 494 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(276,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **ShadowNote** · 370×15 · @(0,57) · size F/H · «Сейчас не влияет — через прокси идёт весь трафик» Manrope 400 11/auto text3 1 строка…
      - **App row** · 370×50 · @(0,78) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-chrome.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text3
      - **App row** · 370×50 · @(0,134) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-dolphin-anty.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text3
      - **App row** · 370×50 · @(0,190) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-telegram.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 73×15 · @(0,20) · size H/H · «не запущено» Mono 400 11/15 text3
  - **Footer switch** · 418×69 · @(1,570) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Вкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **KillSwitchNote** · 418×24 · @(0,1) · size F/H · row gap 6 pad 8 24 0 24 start/center
      - **icon/sglobe** · 16×16 · @(24,8) · size F/F · icon `shield-globe-16.svg` text3
      - **t:Прокси упадёт — инте** · 348×15 · @(46,8.5) · size F/H · «Прокси упадёт — интернет на паузе, IP не утечёт» Manrope 400 11/15 text3
    - **Switch** · 418×44 · @(0,25) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 140×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg accentSoft · border 1 accent · r 14
        - **Proxy dot** · 8×8 · @(11,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 4 · ⟨Proxy dot / Proxy=1, Size=8⟩
        - **t:через Прокси 1** · 88×17 · @(25,5.5) · size H/H · «через Прокси 1» Manrope 600 12/17 accentText
        - **icon/chevron** · 12×12 · @(119,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## d · Выбор прокси

Пилюля в состоянии Open, под ней MenuFlyout `ProxyPicker` (340 px, absolute, x=40 y=220). Шапка «Текущий прокси · пинг сейчас · ⟳». Пункты: Selected (индикатор 3×16 accent, галочка), Unavailable (приглушён: dot 0.4, заголовок 0.5, «Недоступен · 1 мин назад», кнопка «Проверить»), Default. Затем «Напрямую» и «Управление прокси… Ctrl+P». Тег «быстрый» (`Быстрый=true`) — на Прокси 3 (VLESS, 64 мс): самый быстрый **доступный** прокси, который **не** текущий (правило — в behavior.md).

- Размер: **420×640** · Figma: светлая `73:407`, тёмная `73:2566`
- Данные: [`layout/d_vybor_proksi.json`](layout/d_vybor_proksi.json) · Эталон: [`reference/screens/d_vybor_proksi.html`](../reference/screens/d_vybor_proksi.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/d_vybor_proksi.png) · [тёмная](../design/dark/d_vybor_proksi.png) · без тени: [светлая](../design/frame-only/light/d_vybor_proksi.png) · [тёмная](../design/frame-only/dark/d_vybor_proksi.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / d Выбор прокси** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 370×25 · @(24,58) · size F/H · «4 приложения идут через прокси» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «2 работают · 1 не запущено · 1 с ошибкой» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 2 accent · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Open⟩
      - **Badge** · 44×44 · @(10,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 167×38 · @(64,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 167×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(241,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(306,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(344,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 418×378 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×279 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 370×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
          - **text** · 221×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 221×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(277,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 370×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
          - **text** · 221×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 221×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(277,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 370×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
          - **text** · 204×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Telegram** · 204×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
            - **t:Запустите — пойдёт ч** · 204×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/idle** · 98×24 · @(260,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
            - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
      - **App row** · 370×111 · @(0,168) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg dangerSoft · border 1 danger · r 8 · ⟨App row / State=Ошибка (раскрыта)⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-discord.svg` 
          - **text** · 230×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Discord** · 230×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text 1 строка…
            - **t:Соединения не проход** · 230×15 · @(0,20) · size F/H · «Соединения не проходят» Manrope 400 11/15 danger 1 строка…
          - **Status/err** · 72×24 · @(286,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg danger · r 12
            - **icon/error** · 12×12 · @(6,6) · size F/F · icon `error-circle-12.svg` onAccent
            - **t:Ошибка** · 42×15 · @(22,4.5) · size H/H · «Ошибка» Manrope 600 11/15 onAccent
        - **ErrorPanel** · 368×61 · @(1,49) · size F/H · col gap 8 pad 0 10 10 46 start/start
          - **t:Прокси 1 не пропуска** · 312×15 · @(46,0) · size F/H · «Прокси 1 не пропускает UDP — звонки не работают.» Manrope 400 11/15 text2
          - **Actions** · 143×28 · @(46,23) · size H/H · row gap 8 pad 0 0 0 0 start/center
            - **Retry button** · 143×28 · @(0,0) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4 · ⟨Retry button / Kind=Primary, State=Default⟩
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2
  - **ProxyPicker (MenuFlyout)** · 340×294 · @(40,220) · size F/H · col gap 2 pad 4 4 4 4 start/start · bg flyout · border 1 stroke · r 8 · shadow shadow/flyout · absolute
    - **Header** · 330×32 · @(5,5) · size F/F · row gap 8 pad 0 2 0 12 start/center
      - **t:Текущий прокси** · 214×17 · @(12,7.5) · size F/H · «Текущий прокси» Manrope 600 12/17 text2
      - **t:пинг сейчас** · 58×14 · @(234,9) · size H/H · «пинг сейчас» Manrope 400 10/14 text3
      - **Button/subtle** · 28×28 · @(300,2) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/sync** · 16×16 · @(6,6) · size F/F · icon `arrow-sync-16.svg` text2
    - **Proxy menu item** · 330×52 · @(5,39) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg accentSoft · r 4 · ⟨Proxy menu item / State=Selected⟩
      - **SelIndicator** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg accent · r 2
      - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center
        - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 5 · ⟨Proxy dot / Proxy=1, Size=10⟩
      - **text** · 188×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 109×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Прокси 1** · 55×18 · @(0,0) · size H/H · «Прокси 1» Manrope 600 13/18 text
          - **Chip/SOCKS5** · 48×18 · @(61,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:Германия · 185.12.••** · 188×15 · @(0,20) · size F/H · «Германия · 185.12.•••.7» Manrope 400 11/15 text3 1 строка…
      - **Ping** · 55×17 · @(239,17.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **CheckSlot** · 16×16 · @(304,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/check** · 16×16 · @(0,0) · size F/F · icon `checkmark-circle-16.svg` accentText
    - **Proxy menu item** · 330×52 · @(5,93) · size F/F · row gap 10 pad 0 6 0 8 start/center · r 4 · ⟨Proxy menu item / State=Unavailable⟩
      - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center · opacity 0.4
        - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p2 · r 5 · ⟨Proxy dot / Proxy=2, Size=10⟩
      - **text** · 161×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 100×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center · opacity 0.5
          - **t:Прокси 2** · 58×18 · @(0,0) · size H/H · «Прокси 2» Manrope 600 13/18 text
          - **Chip/HTTP** · 36×18 · @(64,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:HTTP** · 24×14 · @(6,2) · size H/H · «HTTP» Mono 500 10/14 text2
        - **t:Недоступен · 1 мин н** · 131×15 · @(0,20) · size H/H · «Недоступен · 1 мин назад» Manrope 400 11/15 danger
      - **Button/subtle** · 112×28 · @(212,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/sync** · 16×16 · @(12,6) · size F/F · icon `arrow-sync-16.svg` accentText
        - **t:Проверить** · 64×17 · @(36,5.5) · size H/H · «Проверить» Manrope 500 12/17 accentText
    - **Proxy menu item** · 330×52 · @(5,147) · size F/F · row gap 10 pad 0 10 0 8 start/center · r 4 · ⟨Proxy menu item / State=Default⟩
      - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center
        - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p3 · r 5 · ⟨Proxy dot / Proxy=3, Size=10⟩
      - **text** · 188×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 186×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Прокси 1** · 57×18 · @(0,0) · size H/H · «Прокси 3» Manrope 600 13/18 text
          - **Chip/SOCKS5** · 42×18 · @(63,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 30×14 · @(6,2) · size H/H · «VLESS» Mono 500 10/14 text2
          - **Chip/быстрый** · 75×18 · @(111,0) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg successSoft · r 4
            - **icon/flash** · 16×16 · @(6,1) · size F/F · icon `flash-16.svg` success
            - **t:быстрый** · 43×14 · @(26,2) · size H/H · «быстрый» Manrope 500 10/14 success
        - **t:Германия · 185.12.••** · 188×15 · @(0,20) · size F/H · «Нидерланды · nl-ams.•••.net» Manrope 400 11/15 text3 1 строка…
      - **Ping** · 55×17 · @(239,17.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «64 мс» Mono 500 12/17 success
      - **CheckSlot** · 16×16 · @(304,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
    - **divider** · 330×1 · @(5,201) · size F/F · bg stroke
    - **MenuItem/Напрямую** · 330×44 · @(5,204) · size F/F · row gap 10 pad 0 10 0 8 start/center · r 4
      - **noind** · 3×16 · @(8,14) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **icon/globe** · 16×16 · @(21,14) · size F/F · icon `globe-16.svg` text2
      - **box** · 247×34 · @(47,5) · size F/H · col gap 1 pad 0 0 0 0 start/start
        - **t:Напрямую** · 67×18 · @(0,0) · size H/H · «Напрямую» Manrope 600 13/18 text
        - **t:Без прокси — сайты в** · 247×15 · @(0,19) · size F/H · «Без прокси — сайты видят ваш IP» Manrope 400 11/15 text3 1 строка…
      - **CheckSlot** · 16×16 · @(304,14) · size F/F · row gap 0 pad 0 0 0 0 center/center
    - **divider** · 330×1 · @(5,250) · size F/F · bg stroke
    - **Footer/Управление прокси** · 330×36 · @(5,253) · size F/F · row gap 10 pad 0 10 0 21 start/center · r 4
      - **icon/settings** · 16×16 · @(21,10) · size F/F · icon `settings-16.svg` text2
      - **t:Управление прокси…** · 223×18 · @(47,9) · size F/H · «Управление прокси…» Manrope 400 13/18 text
      - **t:Ctrl+P** · 40×15 · @(280,10.5) · size H/H · «Ctrl+P» Mono 400 11/15 text3

</details>

## e · Управление прокси (отдельное окно 420×560)

Отдельное окно: в заголовке иконка настроек, «Управление прокси — Ashgate Lite», тема и только «Закрыть» (без «Свернуть»). Шапка «Прокси» + чип «3 из 3» (warningSoft) + «Проверить все». Поле вставки заблокировано (opacity 0.6) с текстом «3 из 3 — удалите прокси, чтобы вставить новый». Карточки прокси (тип-чип, «текущий», пинг, адрес моно, действия ⟳ ✎ ⧉ 🗑), карточка с ошибкой (dangerSoft) + RetryBar «Прокси 2 не отвечает уже 1 мин» + «Проверить снова». Футер-подсказка и кнопка «Готово».

- Размер: **420×560** · Figma: светлая `73:616`, тёмная `73:2623`
- Данные: [`layout/e_upravlenie_proksi.json`](layout/e_upravlenie_proksi.json) · Эталон: [`reference/screens/e_upravlenie_proksi.html`](../reference/screens/e_upravlenie_proksi.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/e_upravlenie_proksi.png) · [тёмная](../design/dark/e_upravlenie_proksi.png) · без тени: [светлая](../design/frame-only/light/e_upravlenie_proksi.png) · [тёмная](../design/frame-only/dark/e_upravlenie_proksi.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / e Управление прокси** · 420×560 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar/secondary** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **icon/settings** · 16×16 · @(12,8) · size F/F · icon `settings-16.svg` text2
    - **t:Управление прокси — ** · 196×17 · @(36,7.5) · size H/H · «Управление прокси — Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 86×1 · @(240,15.5) · size F/F
    - **Caption** · 84×32 · @(334,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Close** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Body** · 418×470 · @(1,33) · size F/F · col gap 12 pad 12 16 12 16 start/start
    - **Header** · 386×28 · @(16,12) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Прокси** · 65×25 · @(0,1.5) · size H/H · «Прокси» Manrope 600 18/25 text
      - **Chip/3 из 3** · 54×20 · @(73,4) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg warningSoft · border 1 stroke · r 4
        - **t:3 из 3** · 40×15 · @(7,2.5) · size H/H · «3 из 3» Mono 500 11/15 warning
      - **spacer** · 108×1 · @(135,13.5) · size F/F
      - **Button/subtle** · 135×28 · @(251,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/sync** · 16×16 · @(12,6) · size F/F · icon `arrow-sync-16.svg` text2
        - **t:Проверить все** · 87×17 · @(36,5.5) · size H/H · «Проверить все» Manrope 500 12/17 text2
    - **TextBox/disabled** · 386×32 · @(16,52) · size F/F · col gap 0 pad 0 0 0 0 start/start · bg field · border 1 stroke · r 4 · opacity 0.6
      - **content** · 384×29 · @(1,1) · size F/F · row gap 8 pad 0 8 0 10 start/center
        - **icon/lock** · 16×16 · @(10,6.5) · size F/F · icon `lock-closed-16.svg` text2
        - **t:3 из 3 — удалите про** · 342×18 · @(34,5.5) · size F/H · «3 из 3 — удалите прокси, чтобы вставить новый» Manrope 400 13/18 text3 1 строка…
      - **divider** · 384×1 · @(1,30) · size F/F · bg strokeStrong
    - **ProxyList** · 386×259 · @(16,96) · size F/H · col gap 8 pad 0 0 0 0 start/start
      - **ProxyCard/Прокси 1** · 386×69 · @(0,0) · size F/H · col gap 4 pad 10 6 6 12 start/start · bg surface · border 1 stroke · r 8
        - **box** · 366×19 · @(13,11) · size F/H · row gap 8 pad 0 6 0 0 start/center
          - **dot** · 10×10 · @(0,4.5) · size F/F · bg p1
          - **t:Прокси 1** · 60×19 · @(18,0) · size H/H · «Прокси 1» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(86,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
          - **Chip/текущий** · 55×18 · @(142,0.5) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg accentSoft · border 1 accent · r 4
            - **t:текущий** · 41×14 · @(7,2) · size H/H · «текущий» Manrope 500 10/14 accentText
          - **spacer** · 92×1 · @(205,9) · size F/F
          - **Ping** · 55×17 · @(305,1) · size H/H · row gap 6 pad 0 0 0 0 start/center
            - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
            - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
        - **box** · 366×28 · @(13,34) · size F/H · row gap 2 pad 0 0 0 0 start/center
          - **t:Германия · 185.12.••** · 246×17 · @(0,5.5) · size F/H · «Германия · 185.12.•••.7:1080» Mono 400 12/17 text2 1 строка…
          - **Button/subtle** · 28×28 · @(248,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/sync** · 16×16 · @(6,6) · size F/F · icon `arrow-sync-16.svg` text2
          - **Button/subtle** · 28×28 · @(278,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/edit** · 16×16 · @(6,6) · size F/F · icon `edit-16.svg` text2
          - **Button/subtle** · 28×28 · @(308,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
          - **Button/subtle** · 28×28 · @(338,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/del** · 16×16 · @(6,6) · size F/F · icon `delete-16.svg` danger
      - **ProxyCard/Прокси 2/error** · 386×69 · @(0,77) · size F/H · col gap 4 pad 10 6 6 12 start/start · bg dangerSoft · border 1 danger · r 8
        - **box** · 366×19 · @(13,11) · size F/H · row gap 8 pad 0 6 0 0 start/center
          - **dot** · 10×10 · @(0,4.5) · size F/F · bg p2
          - **t:Прокси 2** · 62×19 · @(18,0) · size H/H · «Прокси 2» Manrope 600 14/19 text
          - **Chip/HTTP** · 36×18 · @(88,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:HTTP** · 24×14 · @(6,2) · size H/H · «HTTP» Mono 500 10/14 text2
          - **spacer** · 153×1 · @(132,9) · size F/F
          - **box** · 67×16 · @(293,1.5) · size H/H · row gap 4 pad 0 0 0 0 start/center
            - **icon/error** · 16×16 · @(0,0) · size F/F · icon `error-circle-16.svg` danger
            - **t:таймаут** · 47×15 · @(20,0.5) · size H/H · «таймаут» Mono 400 11/15 danger
        - **box** · 366×28 · @(13,34) · size F/H · row gap 2 pad 0 0 0 0 start/center
          - **t:США · 91.204.•••.33:** · 246×17 · @(0,5.5) · size F/H · «США · 91.204.•••.33:8080» Mono 400 12/17 text2 1 строка…
          - **Button/subtle** · 28×28 · @(248,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/sync** · 16×16 · @(6,6) · size F/F · icon `arrow-sync-16.svg` text2
          - **Button/subtle** · 28×28 · @(278,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/edit** · 16×16 · @(6,6) · size F/F · icon `edit-16.svg` text2
          - **Button/subtle** · 28×28 · @(308,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
          - **Button/subtle** · 28×28 · @(338,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/del** · 16×16 · @(6,6) · size F/F · icon `delete-16.svg` danger
      - **RetryBar** · 386×28 · @(0,154) · size F/H · row gap 8 pad 0 4 0 4 start/center
        - **icon/error** · 16×16 · @(4,6) · size F/F · icon `error-circle-16.svg` danger
        - **t:Прокси 2 не отвечает** · 201×17 · @(28,5.5) · size F/H · «Прокси 2 не отвечает уже 1 мин» Manrope 400 12/17 danger
        - **Retry button** · 145×28 · @(237,0) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg control · border 1 stroke · r 4 · ⟨Retry button / Kind=Secondary, State=Default⟩
          - **icon/sync** · 16×16 · @(11,6) · size F/F · icon `arrow-sync-16.svg` text
          - **t:Проверить снова** · 101×17 · @(33,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 text
      - **ProxyCard/Прокси 3** · 386×69 · @(0,190) · size F/H · col gap 4 pad 10 6 6 12 start/start · bg surface · border 1 stroke · r 8
        - **box** · 366×19 · @(13,11) · size F/H · row gap 8 pad 0 6 0 0 start/center
          - **dot** · 10×10 · @(0,4.5) · size F/F · bg p3
          - **t:Прокси 3** · 62×19 · @(18,0) · size H/H · «Прокси 3» Manrope 600 14/19 text
          - **Chip/VLESS** · 42×18 · @(88,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:VLESS** · 30×14 · @(6,2) · size H/H · «VLESS» Mono 500 10/14 text2
          - **spacer** · 159×1 · @(138,9) · size F/F
          - **Ping** · 55×17 · @(305,1) · size H/H · row gap 6 pad 0 0 0 0 start/center
            - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
            - **t:64 мс** · 36×17 · @(19,0) · size H/H · «64 мс» Mono 500 12/17 success
        - **box** · 366×28 · @(13,34) · size F/H · row gap 2 pad 0 0 0 0 start/center
          - **t:Нидерланды · nl-ams.** · 246×17 · @(0,5.5) · size F/H · «Нидерланды · nl-ams.•••.net:443» Mono 400 12/17 text2 1 строка…
          - **Button/subtle** · 28×28 · @(248,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/sync** · 16×16 · @(6,6) · size F/F · icon `arrow-sync-16.svg` text2
          - **Button/subtle** · 28×28 · @(278,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/edit** · 16×16 · @(6,6) · size F/F · icon `edit-16.svg` text2
          - **Button/subtle** · 28×28 · @(308,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
          - **Button/subtle** · 28×28 · @(338,0) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
            - **icon/del** · 16×16 · @(6,6) · size F/F · icon `delete-16.svg` danger
  - **Footer** · 418×56 · @(1,503) · size F/F · row gap 8 pad 0 16 0 16 start/center · bg surface
    - **t:Ссылку можно вставит** · 311×15 · @(16,20.5) · size F/H · «Ссылку можно вставить в любом окне — Ctrl+V» Manrope 400 11/15 text3
    - **Button/accent** · 67×32 · @(335,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · bg accent · r 4
      - **t:Готово** · 43×18 · @(12,7) · size H/H · «Готово» Manrope 500 13/18 onAccent

</details>

## f · Поиск приложения («Добавить»)

Экран добавления: «назад» + «Добавить приложение», поле поиска в фокусе (нижняя линия 2 px accent), «Найдено N», результаты с иконкой, путём к .exe (моно, обрезка) и чипом источника (Запущено / Program Files / Пуск). Выбранный результат — surfaceHover + рамка accent. Предпросмотр «Так оно появится в списке:» (App row Не запущено), внизу широкая кнопка «Добавить  Enter».

- Размер: **420×640** · Figma: светлая `73:742`, тёмная `73:2724`
- Данные: [`layout/f_poisk_prilozheniya.json`](layout/f_poisk_prilozheniya.json) · Эталон: [`reference/screens/f_poisk_prilozheniya.html`](../reference/screens/f_poisk_prilozheniya.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/f_poisk_prilozheniya.png) · [тёмная](../design/dark/f_poisk_prilozheniya.png) · без тени: [светлая](../design/frame-only/light/f_poisk_prilozheniya.png) · [тёмная](../design/frame-only/dark/f_poisk_prilozheniya.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / f Поиск приложения** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Subheader** · 418×48 · @(1,33) · size F/F · row gap 8 pad 0 12 0 12 start/center
    - **BackButton** · 32×32 · @(12,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4
      - **icon/chevron** · 16×16 · @(8,8) · size F/F · icon `chevron-up-16.svg` text
    - **t:Добавить приложение** · 180×22 · @(52,13) · size H/H · «Добавить приложение» Manrope 700 16/22 text
  - **Body** · 418×558 · @(1,81) · size F/F · col gap 8 pad 4 16 16 16 start/start
    - **TextBox/focused** · 386×36 · @(16,4) · size F/F · col gap 0 pad 0 0 0 0 start/start · bg fieldFocus · border 1 stroke · r 4
      - **content** · 384×32 · @(1,1) · size F/F · row gap 8 pad 0 8 0 10 start/center
        - **icon/search** · 16×16 · @(10,8) · size F/F · icon `search-16.svg` text
        - **t:dolph** · 342×18 · @(34,7) · size F/H · «dolph» Manrope 400 13/18 text 1 строка…
      - **divider** · 384×2 · @(1,33) · size F/F · bg accent
    - **t:Найдено 3** · 62×17 · @(16,48) · size H/H · «Найдено 3» Manrope 600 12/17 text3
    - **Result/Dolphin Anty/selected** · 386×48 · @(16,73) · size F/F · row gap 10 pad 0 10 0 10 start/center · bg surfaceHover · border 1 accent · r 4
      - **app/dolphin** · 28×28 · @(11,10) · size F/F · icon `app-dolphin-28.svg` 
      - **box** · 233×34 · @(49,7) · size F/H · col gap 1 pad 0 0 0 0 start/start
        - **t:Dolphin Anty** · 233×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
        - **t:C:\Users\Admin\AppDa** · 233×15 · @(0,19) · size F/H · «C:\Users\Admin\AppData\Local\Programs\Dolphin Anty\Dolphin Anty.exe» Mono 400 11/15 text3 1 строка…
      - **Chip/Запущено** · 83×20 · @(292,14) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg control · border 1 stroke · r 4
        - **icon/apps** · 16×16 · @(7,2) · size F/F · icon `apps-16.svg` text2
        - **t:Запущено** · 49×14 · @(27,3) · size H/H · «Запущено» Manrope 500 10/14 text2
    - **Result/Dolphin Anty Beta** · 386×48 · @(16,129) · size F/F · row gap 10 pad 0 10 0 10 start/center · r 4
      - **app/dolphin** · 28×28 · @(10,10) · size F/F · icon `app-dolphin-28.svg` 
      - **box** · 221×34 · @(48,7) · size F/H · col gap 1 pad 0 0 0 0 start/start
        - **t:Dolphin Anty Beta** · 221×18 · @(0,0) · size F/H · «Dolphin Anty Beta» Manrope 600 13/18 text 1 строка…
        - **t:C:\Program Files\Dol** · 221×15 · @(0,19) · size F/H · «C:\Program Files\Dolphin Anty Beta\dolphin_anty.exe» Mono 400 11/15 text3 1 строка…
      - **Chip/Program Files** · 97×20 · @(279,14) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg control · border 1 stroke · r 4
        - **icon/folder** · 16×16 · @(7,2) · size F/F · icon `folder-open-16.svg` text2
        - **t:Program Files** · 63×14 · @(27,3) · size H/H · «Program Files» Manrope 500 10/14 text2
    - **Result/Dolphin Updater** · 386×48 · @(16,185) · size F/F · row gap 10 pad 0 10 0 10 start/center · r 4
      - **app/exe** · 28×28 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg control · border 1 stroke · r 7
        - **icon/window** · 20×20 · @(4,4) · size F/F · icon `window-20.svg` text2
      - **box** · 261×34 · @(48,7) · size F/H · col gap 1 pad 0 0 0 0 start/start
        - **t:Dolphin Updater** · 261×18 · @(0,0) · size F/H · «Dolphin Updater» Manrope 600 13/18 text 1 строка…
        - **t:C:\Users\Admin\AppDa** · 261×15 · @(0,19) · size F/H · «C:\Users\Admin\AppData\Local\Dolphin\updater.exe» Mono 400 11/15 text3 1 строка…
      - **Chip/Пуск** · 57×20 · @(319,14) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg control · border 1 stroke · r 4
        - **icon/apps** · 16×16 · @(7,2) · size F/F · icon `apps-16.svg` text2
        - **t:Пуск** · 23×14 · @(27,3) · size H/H · «Пуск» Manrope 500 10/14 text2
    - **t:Так оно появится в с** · 158×17 · @(16,241) · size H/H · «Так оно появится в списке:» Manrope 600 12/17 text3
    - **App row** · 386×50 · @(16,266) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
      - **Line** · 384×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
        - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
        - **text** · 220×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
          - **t:Telegram** · 220×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
          - **t:Запустите — пойдёт ч** · 220×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
        - **Status/idle** · 98×24 · @(276,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
          - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
          - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
    - **spacer** · 1×174 · @(16,324) · size F/F
    - **Button/accent** · 386×36 · @(16,506) · size F/F · row gap 8 pad 0 12 0 12 center/center · bg accent · r 4
      - **t:Добавить** · 61×18 · @(142,9) · size H/H · «Добавить» Manrope 500 13/18 onAccent
      - **t:Enter** · 33×15 · @(211,10.5) · size H/H · opacity 0.7 · «Enter» Mono 400 11/15 onAccent

</details>

## g · Прокси упал

Текущий прокси не отвечает: заголовок «Прокси 1 не отвечает», подзаголовок «Приложения на паузе — IP не утёк» (kill switch). Пилюля State=Error. Под ней карточка SwitchSuggestion (successSoft, радиус 16): «Быстрее всех: Прокси 3 · Нидерланды · 64 мс», кнопки «Проверить снова» (Secondary) и «Переключиться на быстрейший» (accent). Приложения — «Проверяем…» / «На паузе — ждём прокси».

- Размер: **420×640** · Figma: светлая `73:828`, тёмная `73:2787`
- Данные: [`layout/g_proksi_upal.json`](layout/g_proksi_upal.json) · Эталон: [`reference/screens/g_proksi_upal.html`](../reference/screens/g_proksi_upal.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/g_proksi_upal.png) · [тёмная](../design/dark/g_proksi_upal.png) · без тени: [светлая](../design/frame-only/light/g_proksi_upal.png) · [тёмная](../design/frame-only/dark/g_proksi_upal.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / g Прокси упал** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg danger · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 370×25 · @(24,58) · size F/H · «Прокси 1 не отвечает» Manrope 700 18/25 danger center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «Приложения на паузе — IP не утёк» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 2 danger · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Error⟩
      - **Badge** · 44×44 · @(10,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:3** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 151×38 · @(64,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Нидерланды** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/VLESS** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:VLESS** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:Не отвечает 40 с** · 151×17 · @(0,21) · size F/H · «Не отвечает 40 с» Mono 400 12/17 danger 1 строка…
      - **Ping/error** · 71×17 · @(225,21.5) · size H/H · row gap 4 pad 0 0 0 0 start/center
        - **icon/error** · 16×16 · @(0,0.5) · size F/F · icon `error-circle-16.svg` danger
        - **t:таймаут** · 51×17 · @(20,0) · size H/H · «таймаут» Mono 400 12/17 danger
      - **Button/subtle** · 28×28 · @(306,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(344,22) · size F/F · icon `chevron-down-16.svg` text2
  - **SuggestWrap** · 418×92 · @(1,216) · size F/H · row gap 0 pad 10 0 0 0 center/center
    - **SwitchSuggestion** · 372×82 · @(23,10) · size F/H · col gap 10 pad 12 10 12 10 start/start · bg successSoft · border 1 success · r 16
      - **box** · 350×18 · @(11,13) · size F/H · row gap 8 pad 0 0 0 0 start/center
        - **icon/flash** · 16×16 · @(0,1) · size F/F · icon `flash-16.svg` success
        - **t:Быстрее всех: Прокси** · 263×18 · @(24,0) · size F/H · «Быстрее всех: Прокси 3 · Нидерланды» Manrope 600 13/18 text
        - **Ping** · 55×17 · @(295,0.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
            - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
            - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
            - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
          - **t:64 мс** · 36×17 · @(19,0) · size H/H · «64 мс» Mono 500 12/17 success
      - **box** · 350×28 · @(11,41) · size F/H · row gap 6 pad 0 0 0 0 start/center
        - **Retry button** · 141×28 · @(0,0) · size H/F · row gap 6 pad 0 8 0 8 center/center · bg control · border 1 stroke · r 4 · ⟨Retry button / Kind=Secondary, State=Default⟩
          - **icon/sync** · 16×16 · @(9,6) · size F/F · icon `arrow-sync-16.svg` text
          - **t:Проверить снова** · 101×17 · @(31,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 text
        - **Button/accent** · 203×28 · @(147,0) · size F/F · row gap 8 pad 0 8 0 8 center/center · bg accent · r 4
          - **t:Переключиться на быс** · 184×17 · @(9.5,5.5) · size H/H · «Переключиться на быстрейший» Manrope 500 12/17 onAccent
  - **Rules** · 418×286 · @(1,308) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×162 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 370×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Проверяем⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
          - **text** · 203×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Discord** · 203×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
            - **t:Соединения не проход** · 203×15 · @(0,20) · size F/H · «На паузе — ждём прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/chk** · 99×24 · @(259,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **icon/sync** · 12×12 · @(6,6) · size F/F · icon `arrow-sync-12.svg` text2
            - **t:Проверяем…** · 69×15 · @(22,4.5) · size H/H · «Проверяем…» Manrope 600 11/15 text2
      - **App row** · 370×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Проверяем⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
          - **text** · 203×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Discord** · 203×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
            - **t:Соединения не проход** · 203×15 · @(0,20) · size F/H · «На паузе — ждём прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/chk** · 99×24 · @(259,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **icon/sync** · 12×12 · @(6,6) · size F/F · icon `arrow-sync-12.svg` text2
            - **t:Проверяем…** · 69×15 · @(22,4.5) · size H/H · «Проверяем…» Manrope 600 11/15 text2
      - **App row** · 370×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
          - **text** · 204×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Telegram** · 204×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
            - **t:Запустите — пойдёт ч** · 204×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/idle** · 98×24 · @(260,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
            - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## h · Компакт 360×520

Минимальный размер окна. Та же структура, что b: заголовок 18 px (не уменьшается), ширины 310/328/326, меньше строк, футер сохраняется.

- Размер: **360×520** · Figma: светлая `73:952`, тёмная `73:2837`
- Данные: [`layout/h_kompakt_360x520.json`](layout/h_kompakt_360x520.json) · Эталон: [`reference/screens/h_kompakt_360x520.html`](../reference/screens/h_kompakt_360x520.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/h_kompakt_360x520.png) · [тёмная](../design/dark/h_kompakt_360x520.png) · без тени: [светлая](../design/frame-only/light/h_kompakt_360x520.png) · [тёмная](../design/frame-only/dark/h_kompakt_360x520.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / h Компакт 360×520** · 360×520 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 358×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 106×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(228,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 358×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(143,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 310×25 · @(24,58) · size F/H · «4 приложения идут через прокси» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 310×18 · @(24,93) · size F/H · «2 работают · 1 не запущено» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 358×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 328×60 · @(15,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 125×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 125×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(198,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(263,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(301,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 358×258 · @(1,216) · size F/F · col gap 6 pad 10 16 0 16 start/start
    - **SectionHeader** · 326×28 · @(16,10) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 124×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(221,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 326×162 · @(16,44) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 326×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 324×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
          - **text** · 177×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 177×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(233,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 326×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 324×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
          - **text** · 177×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 177×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(233,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 326×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
        - **Line** · 324×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
          - **text** · 160×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Telegram** · 160×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
            - **t:Запустите — пойдёт ч** · 160×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/idle** · 98×24 · @(216,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
            - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
  - **Footer switch** · 358×45 · @(1,474) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Выкл⟩
    - **divider** · 358×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 358×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## i · Проверяем

Состояние после «Проверить снова»: подзаголовок «Проверяем Discord…», строка Discord в состоянии Проверяем («Проверяем соединение через Прокси 1…», панель свёрнута).

- Размер: **420×640** · Figma: светлая `73:1058`, тёмная `73:2871`
- Данные: [`layout/i_proveryaem.json`](layout/i_proveryaem.json) · Эталон: [`reference/screens/i_proveryaem.html`](../reference/screens/i_proveryaem.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/i_proveryaem.png) · [тёмная](../design/dark/i_proveryaem.png) · без тени: [светлая](../design/frame-only/light/i_proveryaem.png) · [тёмная](../design/frame-only/dark/i_proveryaem.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / i Проверяем** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 370×25 · @(24,58) · size F/H · «4 приложения идут через прокси» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «Проверяем Discord…» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 418×378 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×218 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 370×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
          - **text** · 221×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 221×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(277,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 370×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Работает⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
          - **text** · 221×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 221×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(277,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **App row** · 370×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Не запущено⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
          - **text** · 204×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Telegram** · 204×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
            - **t:Запустите — пойдёт ч** · 204×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
          - **Status/idle** · 98×24 · @(260,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
            - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
      - **App row** · 370×50 · @(0,168) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8 · ⟨App row / State=Проверяем⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-discord.svg` 
          - **text** · 203×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Discord** · 203×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text 1 строка…
            - **t:Соединения не проход** · 203×15 · @(0,20) · size F/H · «Проверяем соединение через Прокси 1…» Manrope 400 11/15 text3 1 строка…
          - **Status/chk** · 99×24 · @(259,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
            - **icon/sync** · 12×12 · @(6,6) · size F/F · icon `arrow-sync-12.svg` text2
            - **t:Проверяем…** · 69×15 · @(22,4.5) · size H/H · «Проверяем…» Manrope 600 11/15 text2
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## j · Компакт · весь трафик

Режим «весь трафик» в окне 360×520 (как c, ширины компакта).

- Размер: **360×520** · Figma: светлая `73:1178`, тёмная `73:2906`
- Данные: [`layout/j_kompakt_ves_trafik.json`](layout/j_kompakt_ves_trafik.json) · Эталон: [`reference/screens/j_kompakt_ves_trafik.html`](../reference/screens/j_kompakt_ves_trafik.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/j_kompakt_ves_trafik.png) · [тёмная](../design/dark/j_kompakt_ves_trafik.png) · без тени: [светлая](../design/frame-only/light/j_kompakt_ves_trafik.png) · [тёмная](../design/frame-only/dark/j_kompakt_ves_trafik.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / j Компакт · весь трафик** · 360×520 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 358×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 106×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(228,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 358×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/On** · 72×36 · @(143,12) · size F/F · row gap 0 pad 0 5 0 5 end/center · bg accent · r 18
      - **knob** · 24×24 · @(43,6) · size F/F · bg onAccent
    - **Headline** · 310×25 · @(24,58) · size F/H · «Весь трафик → Прокси 1» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 310×18 · @(24,93) · size F/H · «Все приложения Windows · SOCKS5 · Германия» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 358×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 328×60 · @(15,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 125×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 125×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(198,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(263,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(301,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 358×234 · @(1,216) · size F/F · col gap 6 pad 10 16 0 16 start/start
    - **SectionHeader** · 326×28 · @(16,10) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 124×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(221,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 326×184 · @(16,44) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **AllAppsRow** · 326×51 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg accentSoft · border 1.5 accent · r 8
        - **Line** · 323×48 · @(1.5,1.5) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **OthersIcon** · 24×24 · @(12,12) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg accentSoft · r 6
            - **icon/globe** · 16×16 · @(4,4) · size F/F · icon `globe-16.svg` accentText
          - **text** · 176×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Остальные приложения** · 176×18 · @(0,0) · size F/H · «Все приложения Windows» Manrope 600 13/18 text 1 строка…
            - **t:↓ 2,1 МБ/с   ↑ 310 К** · 152×15 · @(0,20) · size H/H · «↓ 4,4 МБ/с   ↑ 494 КБ/с» Mono 400 11/15 text2
          - **Status/ok** · 81×24 · @(232,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
            - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
            - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **ShadowNote** · 326×15 · @(0,57) · size F/H · «Сейчас не влияет — через прокси идёт весь трафик» Manrope 400 11/auto text3 1 строка…
      - **App row** · 326×50 · @(0,78) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 324×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-chrome.svg` 
          - **text** · 268×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 268×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text3
      - **App row** · 326×50 · @(0,134) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 324×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-dolphin-anty.svg` 
          - **text** · 268×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 268×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text3
  - **Footer switch** · 358×69 · @(1,450) · size F/H · col gap 0 pad 0 0 0 0 start/start · ⟨Footer switch / State=Вкл⟩
    - **divider** · 358×1 · @(0,0) · size F/F · bg stroke
    - **KillSwitchNote** · 358×24 · @(0,1) · size F/H · row gap 6 pad 8 24 0 24 start/center
      - **icon/sglobe** · 16×16 · @(24,8) · size F/F · icon `shield-globe-16.svg` text3
      - **t:Прокси упадёт — инте** · 288×15 · @(46,8.5) · size F/H · «Прокси упадёт — интернет на паузе, IP не утечёт» Manrope 400 11/15 text3
    - **Switch** · 358×44 · @(0,25) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 140×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg accentSoft · border 1 accent · r 14
        - **Proxy dot** · 8×8 · @(11,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 4 · ⟨Proxy dot / Proxy=1, Size=8⟩
        - **t:через Прокси 1** · 88×17 · @(25,5.5) · size H/H · «через Прокси 1» Manrope 600 12/17 accentText
        - **icon/chevron** · 12×12 · @(119,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## k · Редактирование прокси (окно 420×560)

Открывается по ✎ на карточке прокси в окне «Управление прокси» (e); то же окно, тот же заголовок. Шапка: точка прокси + «Прокси 1» + чип «текущий» (если прокси текущий). Поле — то же, что поле вставки ссылки (TextBox в фокусе, как в f, без иконки поиска) с подписью «Ссылка прокси», заполнено ссылкой этого прокси. Футер: «Удалить» (subtle, danger, иконка 🗑 — то же действие, что 🗑 в e) слева; «Отмена» (standard) и «Сохранить» (accent) справа. Других полей и кнопок нет.

- Размер: **420×560** · Figma: светлая `102:1591`, тёмная `102:1722`
- Данные: [`layout/k_redaktirovanie_proksi.json`](layout/k_redaktirovanie_proksi.json) · Эталон: [`reference/screens/k_redaktirovanie_proksi.html`](../reference/screens/k_redaktirovanie_proksi.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/k_redaktirovanie_proksi.png) · [тёмная](../design/dark/k_redaktirovanie_proksi.png) · без тени: [светлая](../design/frame-only/light/k_redaktirovanie_proksi.png) · [тёмная](../design/frame-only/dark/k_redaktirovanie_proksi.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / k Редактирование прокси** · 420×560 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar/secondary** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **icon/settings** · 16×16 · @(12,8) · size F/F · icon `settings-16.svg` text2
    - **Управление прокси — Ashgate Lite** · 196×17 · @(36,7.5) · size H/H · «Управление прокси — Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 86×1 · @(240,15.5) · size F/F
    - **Caption** · 84×32 · @(334,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Close** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Body** · 418×470 · @(1,33) · size F/F · col gap 12 pad 12 16 12 16 start/start
    - **Header** · 386×25 · @(16,12) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **dot** · 10×10 · @(0,7.5) · size F/F · bg p1
      - **Прокси 1** · 77×25 · @(18,0) · size H/H · «Прокси 1» Manrope 600 18/25 text
      - **Chip/текущий** · 55×18 · @(103,3.5) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg accentSoft · border 1 accent · r 4
        - **текущий** · 41×14 · @(7,2) · size H/H · «текущий» Manrope 500 10/14 accentText
    - **Ссылка прокси** · 89×17 · @(16,49) · size H/H · «Ссылка прокси» Manrope 600 12/17 text3
    - **TextBox/focused** · 386×36 · @(16,78) · size F/F · col gap 0 pad 0 0 0 0 start/start · bg fieldFocus · border 1 stroke · r 4
      - **content** · 384×32 · @(1,1) · size F/F · row gap 8 pad 0 8 0 10 start/center
        - **icon/search** · 16×16 · @(10,8) · size F/F · hidden · ⟨Search / Size=16, Theme=Regular⟩
        - **socks5://185.12.•••.7:1080** · 366×18 · @(10,7) · size F/H · «socks5://185.12.•••.7:1080» Manrope 400 13/18 text 1 строка…
      - **divider** · 384×2 · @(1,33) · size F/F · bg accent
  - **Footer** · 418×56 · @(1,503) · size F/F · row gap 8 pad 0 16 0 16 start/center · bg surface
    - **Button/subtle/danger** · 96×32 · @(16,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
      - **icon/del** · 16×16 · @(12,8) · size F/F · icon `delete-16.svg` danger
      - **Удалить** · 48×17 · @(36,7.5) · size H/H · «Удалить» Manrope 500 12/17 danger
    - **spacer** · 98×1 · @(120,27.5) · size F/F
    - **Button/standard** · 75×32 · @(226,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · bg control · border 1 stroke · r 4
      - **Отмена** · 49×18 · @(13,7) · size H/H · «Отмена» Manrope 500 13/18 text
    - **Button/accent** · 93×32 · @(309,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · bg accent · r 4
      - **Сохранить** · 69×18 · @(12,7) · size H/H · «Сохранить» Manrope 500 13/18 onAccent

</details>

## l · Выключено (прокси есть, переключатель выкл)

Вариант b, когда прокси уже добавлен, но главный переключатель выключен. `BigToggle/Off` (полная непрозрачность, в отличие от a), заголовок одной строкой «Пока всё идёт напрямую», подзаголовок «Выключено · включите, чтобы пустить через прокси». Пилюля текущего прокси — Default. Все строки приложений — **В тени** (без пилюли статуса), вторая строка «идёт напрямую» (или «не запущено»). Футер приглушён (opacity 0.5), как в a.

- Размер: **420×640** · Figma: светлая `101:1423`, тёмная `101:1594`
- Данные: [`layout/l_vyklyucheno.json`](layout/l_vyklyucheno.json) · Эталон: [`reference/screens/l_vyklyucheno.html`](../reference/screens/l_vyklyucheno.html) (`?theme=dark`)
- PNG 2x: [светлая](../design/light/l_vyklyucheno.png) · [тёмная](../design/dark/l_vyklyucheno.png) · без тени: [светлая](../design/frame-only/light/l_vyklyucheno.png) · [тёмная](../design/frame-only/dark/l_vyklyucheno.png)

<details><summary>Конспект дерева</summary>

- **Ashgate Lite / Светлая / l Выключено** · 420×640 · @(0,0) · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 winStroke · r 8 · shadow shadow/window
  - **TitleBar** · 418×32 · @(1,1) · size F/F · row gap 8 pad 0 0 0 12 start/center
    - **Ashgate logo** · 16×16 · @(12,8) · size F/F · icon `ashgate-logo.svg` 
    - **t:Ashgate Lite** · 70×17 · @(36,7.5) · size H/H · «Ashgate Lite» Manrope 400 12/17 text2
    - **spacer** · 166×1 · @(114,15.5) · size F/F
    - **Caption** · 130×32 · @(288,0) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Theme toggle** · 32×28 · @(0,2) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4 · ⟨Theme toggle / State=Default⟩
        - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
      - **gap** · 6×1 · @(32,15.5) · size F/F · row gap 0 pad 0 0 0 0 start/center
      - **Caption/Minimize** · 46×32 · @(38,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/subtract** · 16×16 · @(15,8) · size F/F · icon `subtract-16.svg` text2
      - **Caption/Close** · 46×32 · @(84,0) · size F/F · row gap 0 pad 0 0 0 0 center/center
        - **icon/dismiss** · 16×16 · @(15,8) · size F/F · icon `dismiss-16.svg` text2
  - **Hero** · 418×123 · @(1,33) · size F/H · col gap 10 pad 12 24 12 24 start/center
    - **BigToggle/Off** · 72×36 · @(173,12) · size F/F · row gap 0 pad 0 5 0 5 start/center · bg surface · border 1.5 strokeStrong · r 18
      - **knob** · 24×24 · @(6.5,6) · size F/F · bg text2
    - **Headline** · 370×25 · @(24,58) · size F/H · «Пока всё идёт напрямую» Manrope 700 18/25 text center 1 строка…
    - **Subtitle** · 370×18 · @(24,93) · size F/H · «Выключено · включите, чтобы пустить через прокси» Manrope 400 13/18 text2 center 1 строка…
  - **CurrentWrap** · 418×60 · @(1,156) · size F/H · row gap 0 pad 0 0 0 0 center/center
    - **Current proxy pill** · 372×60 · @(23,0) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill · ⟨Current proxy pill / State=Default⟩
      - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
        - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
      - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
          - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
          - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
            - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
      - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
          - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
          - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
          - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
        - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
      - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
      - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **Rules** · 418×378 · @(1,216) · size F/F · col gap 6 pad 14 24 0 24 start/start
    - **SectionHeader** · 370×28 · @(24,14) · size F/H · row gap 8 pad 0 0 0 0 start/center
      - **t:Приложения** · 81×18 · @(0,5) · size H/H · «Приложения» Manrope 600 13/18 text2
      - **spacer** · 168×1 · @(89,13.5) · size F/F
      - **Button/subtle** · 105×28 · @(265,0) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
        - **icon/add** · 16×16 · @(12,6) · size F/F · icon `add-16.svg` accentText
        - **t:Добавить** · 57×17 · @(36,5.5) · size H/H · «Добавить» Manrope 500 12/17 accentText
    - **AppList** · 370×218 · @(24,48) · size F/H · col gap 6 pad 0 0 0 0 start/start
      - **App row** · 370×50 · @(0,0) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-chrome.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 86×15 · @(0,20) · size H/H · «идёт напрямую» Mono 400 11/15 text3
      - **App row** · 370×50 · @(0,56) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-dolphin-anty.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 86×15 · @(0,20) · size H/H · «идёт напрямую» Mono 400 11/15 text3
      - **App row** · 370×50 · @(0,112) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-telegram.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 73×15 · @(0,20) · size H/H · «не запущено» Mono 400 11/15 text3
      - **App row** · 370×50 · @(0,168) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8 · ⟨App row / State=В тени⟩
        - **Line** · 368×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
          - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-discord.svg` 
          - **text** · 312×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
            - **t:Chrome** · 312×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text2 1 строка…
            - **t:↓ 1,4 МБ/с   ↑ 120 К** · 86×15 · @(0,20) · size H/H · «идёт напрямую» Mono 400 11/15 text3
  - **Footer switch** · 418×45 · @(1,594) · size F/H · col gap 0 pad 0 0 0 0 start/start · opacity 0.5 · ⟨Footer switch / State=Выкл⟩
    - **divider** · 418×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 418×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2

</details>
