# Мост Go ↔ JS (WebView2)

Здесь описан **контракт данных для UI**. В нём только то, что нужно экранам a–l. Новые поля и функции не добавлять. Транспорт: WebView2 `window.chrome.webview.postMessage` / событие `message`, либо привязки Go (например, `webview.Bind`). Ниже приведены JSON-формы, которые не зависят от транспорта.

## Конверт сообщений

```jsonc
// JS → Go (команда)
{ "id": "c-17", "cmd": "proxy.select", "args": { "proxyId": "p3" } }
// Go → JS (ответ на команду)
{ "id": "c-17", "ok": true, "result": { } }
{ "id": "c-17", "ok": false, "error": { "code": "PROXY_LIMIT", "message": "3 из 3 — удалите прокси, чтобы вставить новый" } }
// Go → JS (событие)
{ "event": "state", "data": { /* State */ } }
```

## Типы

```ts
type ProxyType = "SOCKS5" | "HTTP" | "VLESS";
type Slot = 1 | 2 | 3;                         // → цвет --color-p1/p2/p3, «Прокси N»

interface Proxy {
  id: string;
  slot: Slot;
  type: ProxyType;
  country: string;          // «Германия»
  hostMasked: string;       // «185.12.•••.7», «nl-ams.•••.net» — маскирует бэкенд
  port: number;             // показывается в e: «…:1080»
  pingMs: number | null;    // null — нет данных
  available: boolean;
  unavailableSince?: number; // unix ms → «Недоступен · N мин назад», «не отвечает уже N мин»
  lastError?: "timeout" | string; // «таймаут»
}

type AppStatus = "running" | "notRunning" | "error" | "checking" | "paused";
interface App {
  id: string;
  name: string;             // «Chrome»
  exePath: string;
  iconDataUrl?: string;     // иконка из .exe (PNG data URL, 24/28 px @2x)
  status: AppStatus;        // "paused" = Приостановлено (идёт напрямую)
  error?: { short: string; detail: string }; // «Соединения не проходят» / «Прокси 1 не пропускает UDP — звонки не работают.»
  downBps?: number; upBps?: number;          // для «↓ 1,4 МБ/с   ↑ 120 КБ/с»
}

interface State {
  enabled: boolean;                    // большой переключатель
  currentProxyId: string | null;       // ровно один текущий или null («Напрямую»/нет прокси)
  proxies: Proxy[];                    // ≤ 3
  apps: App[];
  others: "direct" | { proxyId: string };   // футер «Всё остальное →»
  allTraffic?: { downBps: number; upBps: number }; // строка «Все приложения Windows» в режиме c/j
  proxyDown?: { proxyId: string; sinceMs: number; fastest?: { proxyId: string; pingMs: number } }; // экран g
  theme: "light" | "dark";
}

interface Suggestion {          // экраны a и f
  name: string; exePath: string; iconDataUrl?: string;
  source: "running" | "startMenu" | "programFiles";  // чип «Запущено» / «Пуск» / «Program Files»
}
```

## Команды (JS → Go)

| cmd | args | Результат / эффект | Экран |
|---|---|---|---|
| `state.get` | — | `State` | старт |
| `toggle.set` | `{ enabled }` | событие `state` | a, b |
| `proxy.paste` | `{ text }` (из буфера по Ctrl+V) | `Proxy` или ошибка `PROXY_LIMIT` / `PROXY_PARSE` | a, e |
| `proxy.select` | `{ proxyId \| null }` | текущий прокси (null = Напрямую) | d, g |
| `proxy.ping` | `{ proxyId? }` (без id — все) | события `ping` | d (открытие, ⟳), e («Проверить все») |
| `proxy.check` | `{ proxyId }` | «Проверить» / «Проверить снова» | d, e, g |
| `proxy.switchFastest` | — | текущий = `proxyDown.fastest` | g |
| `proxy.update` | `{ proxyId, text }` (ссылка из поля k) | `Proxy` или ошибка `PROXY_PARSE` | k («Сохранить») |
| `proxy.remove` | `{ proxyId }` | — | e, k («Удалить») |
| `proxy.copy` | `{ proxyId }` | ссылка в буфер | e |
| `others.set` | `{ target: "direct" \| { proxyId } }` | футер | все |
| `apps.suggest` | `{ query }` | `Suggestion[]` (по приоритету источников) | a (query=""), f |
| `apps.add` | `{ exePath }` | `App` | a («+»), f (Enter) |
| `apps.check` | `{ appId }` | статус `checking` → итог | b, i |
| `apps.pause` | `{ appId, paused }` | «Приостановить» | ⋯ |
| `apps.direct` | `{ appId }` | «Пустить напрямую» (только когда `others` ≠ direct) | ⋯ |
| `apps.remove` | `{ appId }` | «Убрать из списка» | ⋯ |
| `settings.setTheme` | `{ theme }` | запись в settings.json | заголовок |
| `window.minimize` / `window.close` / `window.openManage` / `window.startDrag` | — | управление окнами (Ctrl+P → openManage) | заголовки |

## События (Go → JS)

| event | data | Частота |
|---|---|---|
| `state` | `State` целиком | при любом изменении (не чаще 10/с) |
| `speeds` | `{ apps: { [appId]: { downBps, upBps } }, allTraffic?: { downBps, upBps } }` | **1 раз в секунду** |
| `ping` | `{ proxyId, pingMs \| null, available }` | по мере измерения |
| `appStatus` | `{ appId, status, error? }` | при смене |

## settings.json (на диске, пишет Go)

```json
{ "theme": "light" }
```

- Ключ `theme` принимает `"light"` или `"dark"`. Если файла нет, тема `"light"`. Тема Windows не читается.
- Go передаёт тему до загрузки страницы (например, query `?theme=` или атрибут `data-theme` в HTML), чтобы не было вспышки.
- Остальные поля settings.json (прокси, приложения) — внутреннее дело бэкенда, UI их не читает.

## Форматирование на стороне JS

- Скорость отображается в КБ/с до 1000 КБ/с, дальше в МБ/с с одним знаком. Разделитель дробной части — запятая. Формат: `↓ 1,4 МБ/с   ↑ 120 КБ/с` (три пробела).
- Пинг: `48 мс`.
- Время: «N мин назад», «Не отвечает 40 с».
- Счётчики склоняются по-русски (см. [copy.md](copy.md)).
