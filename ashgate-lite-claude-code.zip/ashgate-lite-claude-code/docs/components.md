# Компоненты и варианты

Автогенерация: `python3 tools/gen_docs.py`. Источник истины — `docs/layout/components/<компонент>.json` (корень — Component Set, дети — варианты). Обозначения — как в [screens.md](screens.md). Лист компонентов: [design/components.png](../design/components.png), эталон: `reference/components/<компонент>.html`.

## App row

Строка приложения. **Нет выбора прокси для приложения.** Показывает иконку, имя, вторую строку (скорость «↓ … ↑ …» моно или подсказку) и пилюлю статуса (высота 24, r 12, pad 0 8 0 6, gap 4, иконка 12 + текст). Ошибка раскрывает панель с причиной и **только** кнопкой «Проверить снова». Наведение показывает ⋯ (меню — см. Row menu). «В тени» — фон bg, без пилюли, для режима «весь трафик».

- Figma Component Set: `73:1683` · Данные: [`layout/components/app_row.json`](layout/components/app_row.json) · Эталон: [`reference/components/app_row.html`](../reference/components/app_row.html)

| Вариант | Figma id | Размер |
|---|---|---|
| State=Работает | `73:1657` | 372×50 |
| State=Не запущено | `73:1661` | 372×50 |
| State=Ошибка (раскрыта) | `73:1671` | 372×111 |
| State=Проверяем | `73:1677` | 372×50 |
| State=Наведение | `73:1682` | 372×50 |
| State=В тени | `84:1457` | 372×50 |

<details><summary>Конспект вариантов</summary>

- **App row** · 404×473 · @(0,0) · col gap 16 pad 16 16 16 16 start/start · r 5
  - **State=Работает** · 372×50 · @(16,16) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-chrome.svg` 
      - **text** · 223×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Chrome** · 223×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text 1 строка…
        - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text2
      - **Status/ok** · 81×24 · @(279,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
        - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
        - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
  - **State=Не запущено** · 372×50 · @(16,82) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-telegram.svg` 
      - **text** · 206×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Telegram** · 206×18 · @(0,0) · size F/H · «Telegram» Manrope 600 13/18 text 1 строка…
        - **t:Запустите — пойдёт ч** · 206×15 · @(0,20) · size F/H · «Запустите — пойдёт через прокси» Manrope 400 11/15 text3 1 строка…
      - **Status/idle** · 98×24 · @(262,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
        - **ring** · 10×10 · @(6,7) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.5 text3 · r 5
        - **t:Не запущено** · 70×15 · @(20,4.5) · size H/H · «Не запущено» Manrope 600 11/15 text2
  - **State=Ошибка (раскрыта)** · 372×111 · @(16,148) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg dangerSoft · border 1 danger · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-discord.svg` 
      - **text** · 232×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Discord** · 232×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text 1 строка…
        - **t:Соединения не проход** · 232×15 · @(0,20) · size F/H · «Соединения не проходят» Manrope 400 11/15 danger 1 строка…
      - **Status/err** · 72×24 · @(288,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg danger · r 12
        - **icon/error** · 12×12 · @(6,6) · size F/F · icon `error-circle-12.svg` onAccent
        - **t:Ошибка** · 42×15 · @(22,4.5) · size H/H · «Ошибка» Manrope 600 11/15 onAccent
    - **ErrorPanel** · 370×61 · @(1,49) · size F/H · col gap 8 pad 0 10 10 46 start/start
      - **t:Прокси 1 не пропуска** · 314×15 · @(46,0) · size F/H · «Прокси 1 не пропускает UDP — звонки не работают.» Manrope 400 11/15 text2
      - **Actions** · 143×28 · @(46,23) · size H/H · row gap 8 pad 0 0 0 0 start/center
        - **Retry button** · 143×28 · @(0,0) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4 · ⟨Retry button / Kind=Primary, State=Default⟩
          - **icon/sync** · 16×16 · @(10,6) · size F/F · icon `arrow-sync-16.svg` onAccent
          - **t:Проверить снова** · 101×17 · @(32,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 onAccent
  - **State=Проверяем** · 372×50 · @(16,275) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surface · border 1 stroke · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-discord.svg` 
      - **text** · 205×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Discord** · 205×18 · @(0,0) · size F/H · «Discord» Manrope 600 13/18 text 1 строка…
        - **t:Соединения не проход** · 205×15 · @(0,20) · size F/H · «Соединения не проходят» Manrope 400 11/15 text3 1 строка…
      - **Status/chk** · 99×24 · @(261,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg surfaceHover · r 12
        - **icon/sync** · 12×12 · @(6,6) · size F/F · icon `arrow-sync-12.svg` text2
        - **t:Проверяем…** · 69×15 · @(22,4.5) · size H/H · «Проверяем…» Manrope 600 11/15 text2
  - **State=Наведение** · 372×50 · @(16,341) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg surfaceHover · border 1 strokeStrong · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 6 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · icon `app-dolphin-anty.svg` 
      - **text** · 189×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Dolphin Anty** · 189×18 · @(0,0) · size F/H · «Dolphin Anty» Manrope 600 13/18 text 1 строка…
        - **t:↓ 860 КБ/с   ↑ 64 КБ** · 146×15 · @(0,20) · size H/H · «↓ 860 КБ/с   ↑ 64 КБ/с» Mono 400 11/15 text2
      - **Status/ok** · 81×24 · @(245,12) · size H/F · row gap 4 pad 0 8 0 6 start/center · bg successSoft · r 12
        - **icon/check** · 12×12 · @(6,6) · size F/F · icon `checkmark-circle-12.svg` success
        - **t:Работает** · 51×15 · @(22,4.5) · size H/H · «Работает» Manrope 600 11/15 success
      - **Button/subtle** · 28×28 · @(336,10) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
        - **icon/more** · 16×16 · @(6,6) · size F/F · icon `more-vertical-16.svg` text2
  - **State=В тени** · 372×50 · @(16,407) · size F/H · col gap 0 pad 0 0 0 0 start/start · bg bg · border 1 stroke · r 8
    - **Line** · 370×48 · @(1,1) · size F/F · row gap 10 pad 0 10 0 12 start/center
      - **App icon** · 24×24 · @(12,12) · size F/F · opacity 0.5 · icon `app-chrome.svg` 
      - **text** · 314×35 · @(46,6.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
        - **t:Chrome** · 314×18 · @(0,0) · size F/H · «Chrome» Manrope 600 13/18 text2 1 строка…
        - **t:↓ 1,4 МБ/с   ↑ 120 К** · 152×15 · @(0,20) · size H/H · «↓ 1,4 МБ/с   ↑ 120 КБ/с» Mono 400 11/15 text3

</details>

## Retry button

«Проверить снова». Kind=Primary (accent) / Secondary (control + рамка). State: Default, Hover (opacity 0.9), Проверяем («Проверяем…», неактивна, opacity 0.7).

- Figma Component Set: `73:1650` · Данные: [`layout/components/retry_button.json`](layout/components/retry_button.json) · Эталон: [`reference/components/retry_button.html`](../reference/components/retry_button.html)

| Вариант | Figma id | Размер |
|---|---|---|
| Kind=Primary, State=Default | `73:1644` | 143×28 |
| Kind=Primary, State=Hover | `73:1645` | 143×28 |
| Kind=Primary, State=Проверяем | `73:1646` | 116×28 |
| Kind=Secondary, State=Default | `73:1647` | 145×28 |
| Kind=Secondary, State=Hover | `73:1648` | 145×28 |
| Kind=Secondary, State=Проверяем | `73:1649` | 118×28 |

<details><summary>Конспект вариантов</summary>

- **Retry button** · 177×280 · @(0,0) · col gap 16 pad 16 16 16 16 start/start · r 5
  - **Kind=Primary, State=Default** · 143×28 · @(16,16) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4
    - **icon/sync** · 16×16 · @(10,6) · size F/F · icon `arrow-sync-16.svg` onAccent
    - **t:Проверить снова** · 101×17 · @(32,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 onAccent
  - **Kind=Primary, State=Hover** · 143×28 · @(16,60) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4 · opacity 0.9
    - **icon/sync** · 16×16 · @(10,6) · size F/F · icon `arrow-sync-16.svg` onAccent
    - **t:Проверить снова** · 101×17 · @(32,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 onAccent
  - **Kind=Primary, State=Проверяем** · 116×28 · @(16,104) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg accent · r 4 · opacity 0.7
    - **icon/sync** · 16×16 · @(10,6) · size F/F · icon `arrow-sync-16.svg` onAccent
    - **t:Проверяем…** · 74×17 · @(32,5.5) · size H/H · «Проверяем…» Manrope 500 12/17 onAccent
  - **Kind=Secondary, State=Default** · 145×28 · @(16,148) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg control · border 1 stroke · r 4
    - **icon/sync** · 16×16 · @(11,6) · size F/F · icon `arrow-sync-16.svg` text
    - **t:Проверить снова** · 101×17 · @(33,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 text
  - **Kind=Secondary, State=Hover** · 145×28 · @(16,192) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg controlHover · border 1 stroke · r 4
    - **icon/sync** · 16×16 · @(11,6) · size F/F · icon `arrow-sync-16.svg` text
    - **t:Проверить снова** · 101×17 · @(33,5.5) · size H/H · «Проверить снова» Manrope 500 12/17 text
  - **Kind=Secondary, State=Проверяем** · 118×28 · @(16,236) · size H/F · row gap 6 pad 0 10 0 10 center/center · bg control · border 1 stroke · r 4 · opacity 0.7
    - **icon/sync** · 16×16 · @(11,6) · size F/F · icon `arrow-sync-16.svg` text
    - **t:Проверяем…** · 74×17 · @(33,5.5) · size H/H · «Проверяем…» Manrope 500 12/17 text

</details>

## Footer switch

Футер «Всё остальное →». Выкл — 45 px, выпадашка «напрямую». Вкл — 69 px, выпадашка «через Прокси N» + строка kill switch «Прокси упадёт — интернет на паузе, IP не утечёт».

- Figma Component Set: `73:1687` · Данные: [`layout/components/footer_switch.json`](layout/components/footer_switch.json) · Эталон: [`reference/components/footer_switch.html`](../reference/components/footer_switch.html)

| Вариант | Figma id | Размер |
|---|---|---|
| State=Выкл | `73:1684` | 420×45 |
| State=Вкл | `73:1686` | 420×69 |

<details><summary>Конспект вариантов</summary>

- **Footer switch** · 452×162 · @(0,0) · col gap 16 pad 16 16 16 16 start/start · r 5
  - **State=Выкл** · 420×45 · @(16,16) · size F/H · col gap 0 pad 0 0 0 0 start/start
    - **divider** · 420×1 · @(0,0) · size F/F · bg stroke
    - **Switch** · 420×44 · @(0,1) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 111×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg surfaceHover · r 14
        - **direct-dot** · 8×8 · @(10,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1 text3 · r 4
        - **t:напрямую** · 61×17 · @(24,5.5) · size H/H · «напрямую» Manrope 600 12/17 text
        - **icon/chevron** · 12×12 · @(91,8) · size F/F · icon `chevron-down-12.svg` text2
  - **State=Вкл** · 420×69 · @(16,77) · size F/H · col gap 0 pad 0 0 0 0 start/start
    - **divider** · 420×1 · @(0,0) · size F/F · bg stroke
    - **KillSwitchNote** · 420×24 · @(0,1) · size F/H · row gap 6 pad 8 24 0 24 start/center
      - **icon/sglobe** · 16×16 · @(24,8) · size F/F · icon `shield-globe-16.svg` text3
      - **t:Прокси упадёт — инте** · 350×15 · @(46,8.5) · size F/H · «Прокси упадёт — интернет на паузе, IP не утечёт» Manrope 400 11/15 text3
    - **Switch** · 420×44 · @(0,25) · size F/F · row gap 8 pad 0 24 0 24 start/center
      - **icon/globe** · 16×16 · @(24,14) · size F/F · icon `globe-16.svg` text2
      - **t:Всё остальное →** · 99×17 · @(48,13.5) · size H/H · «Всё остальное →» Manrope 400 12/17 text2
      - **DropDown** · 140×28 · @(155,8) · size H/F · row gap 6 pad 0 8 0 10 start/center · bg accentSoft · border 1 accent · r 14
        - **Proxy dot** · 8×8 · @(11,10) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 4 · ⟨Proxy dot / Proxy=1, Size=8⟩
        - **t:через Прокси 1** · 88×17 · @(25,5.5) · size H/H · «через Прокси 1» Manrope 600 12/17 accentText
        - **icon/chevron** · 12×12 · @(119,8) · size F/F · icon `chevron-down-12.svg` text2

</details>

## Proxy menu item

Пункт меню выбора прокси (330×52 внутри меню 340). Default / Hover / Selected (индикатор accent, accentSoft, галочка) / Disabled / Unavailable (приглушён, «Недоступен · N мин назад», «Проверить»). Тег «быстрый» (`Быстрый#56:0`) — только у самого быстрого доступного прокси, если он не текущий (behavior.md §3).

- Figma Component Set: `73:1488` · Данные: [`layout/components/proxy_menu_item.json`](layout/components/proxy_menu_item.json) · Эталон: [`reference/components/proxy_menu_item.html`](../reference/components/proxy_menu_item.html)

| Вариант | Figma id | Размер |
|---|---|---|
| State=Default | `73:1489` | 332×52 |
| State=Hover | `73:1509` | 332×52 |
| State=Selected | `73:1529` | 332×52 |
| State=Disabled | `73:1550` | 332×52 |
| State=Unavailable | `73:1689` | 332×52 |

<details><summary>Конспект вариантов</summary>

- **Proxy menu item** · 380×372 · @(0,0) · col gap 16 pad 24 24 24 24 start/start · bg bg · r 12
  - **State=Default** · 332×52 · @(24,24) · size F/F · row gap 10 pad 0 10 0 8 start/center · r 4
    - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
    - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 5 · ⟨Пульт / Proxy dot / Proxy=1, Size=10⟩
    - **text** · 190×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 109×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Прокси 1** · 55×18 · @(0,0) · size H/H · «Прокси 1» Manrope 600 13/18 text
        - **Chip/SOCKS5** · 48×18 · @(61,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **Chip/быстрый** · 75×18 · @(115,0) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg successSoft · r 4 · hidden
          - **icon/flash** · 16×16 · @(6,1) · size F/F · ⟨Flash / Size=16, Theme=Regular⟩
          - **t:быстрый** · 43×14 · @(26,2) · size H/H · «быстрый» Manrope 500 10/14 success
      - **t:Германия · 185.12.••** · 190×15 · @(0,20) · size F/H · «Германия · 185.12.•••.7» Manrope 400 11/15 text3 1 строка…
    - **Ping** · 55×17 · @(241,17.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **CheckSlot** · 16×16 · @(306,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
  - **State=Hover** · 332×52 · @(24,92) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surfaceHover · r 4
    - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
    - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 5 · ⟨Пульт / Proxy dot / Proxy=1, Size=10⟩
    - **text** · 190×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 109×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Прокси 1** · 55×18 · @(0,0) · size H/H · «Прокси 1» Manrope 600 13/18 text
        - **Chip/SOCKS5** · 48×18 · @(61,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **Chip/быстрый** · 75×18 · @(115,0) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg successSoft · r 4 · hidden
          - **icon/flash** · 16×16 · @(6,1) · size F/F · ⟨Flash / Size=16, Theme=Regular⟩
          - **t:быстрый** · 43×14 · @(26,2) · size H/H · «быстрый» Manrope 500 10/14 success
      - **t:Германия · 185.12.••** · 190×15 · @(0,20) · size F/H · «Германия · 185.12.•••.7» Manrope 400 11/15 text3 1 строка…
    - **Ping** · 55×17 · @(241,17.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **CheckSlot** · 16×16 · @(306,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
  - **State=Selected** · 332×52 · @(24,160) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg accentSoft · r 4
    - **SelIndicator** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg accent · r 2
    - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center
      - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 5 · ⟨Пульт / Proxy dot / Proxy=1, Size=10⟩
    - **text** · 190×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 109×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Прокси 1** · 55×18 · @(0,0) · size H/H · «Прокси 1» Manrope 600 13/18 text
        - **Chip/SOCKS5** · 48×18 · @(61,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
        - **Chip/быстрый** · 75×18 · @(115,0) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg successSoft · r 4 · hidden
          - **icon/flash** · 16×16 · @(6,1) · size F/F · ⟨Flash / Size=16, Theme=Regular⟩
          - **t:быстрый** · 43×14 · @(26,2) · size H/H · «быстрый» Manrope 500 10/14 success
      - **t:Германия · 185.12.••** · 190×15 · @(0,20) · size F/H · «Германия · 185.12.•••.7» Manrope 400 11/15 text3 1 строка…
    - **Ping** · 55×17 · @(241,17.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **CheckSlot** · 16×16 · @(306,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
      - **icon/check** · 16×16 · @(0,0) · size F/F · icon `checkmark-circle-16.svg` accentText
  - **State=Disabled** · 332×52 · @(24,228) · size F/F · row gap 10 pad 0 10 0 8 start/center · r 4
    - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
    - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center · opacity 0.4
      - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p2 · r 5 · ⟨Пульт / Proxy dot / Proxy=2, Size=10⟩
    - **text** · 178×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 100×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center · opacity 0.5
        - **t:Прокси 2** · 58×18 · @(0,0) · size H/H · «Прокси 2» Manrope 600 13/18 text
        - **Chip/HTTP** · 36×18 · @(64,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:HTTP** · 24×14 · @(6,2) · size H/H · «HTTP» Mono 500 10/14 text2
        - **Chip/быстрый** · 75×18 · @(106,0) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg successSoft · r 4 · hidden
          - **icon/flash** · 16×16 · @(6,1) · size F/F · ⟨Flash / Size=16, Theme=Regular⟩
          - **t:быстрый** · 43×14 · @(26,2) · size H/H · «быстрый» Manrope 500 10/14 success
      - **t:Недоступен · 1 мин н** · 178×15 · @(0,20) · size F/H · «Недоступен · 1 мин назад» Manrope 400 11/15 danger 1 строка…
    - **Ping/error** · 67×16 · @(229,18) · size H/H · row gap 4 pad 0 0 0 0 start/center
      - **icon/error** · 16×16 · @(0,0) · size F/F · icon `error-circle-16.svg` danger
      - **t:таймаут** · 47×15 · @(20,0.5) · size H/H · «таймаут» Mono 400 11/15 danger
    - **CheckSlot** · 16×16 · @(306,18) · size F/F · row gap 0 pad 0 0 0 0 center/center
  - **State=Unavailable** · 332×52 · @(24,296) · size F/F · row gap 10 pad 0 6 0 8 start/center · r 4
    - **noind** · 3×16 · @(8,18) · size F/F · row gap 0 pad 0 0 0 0 start/center
    - **dotWrap** · 10×10 · @(21,21) · size H/H · row gap 0 pad 0 0 0 0 start/center · opacity 0.4
      - **Proxy dot** · 10×10 · @(0,0) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p2 · r 5 · ⟨Proxy dot / Proxy=2, Size=10⟩
    - **text** · 163×35 · @(41,8.5) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 100×18 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center · opacity 0.5
        - **t:Прокси 2** · 58×18 · @(0,0) · size H/H · «Прокси 2» Manrope 600 13/18 text
        - **Chip/HTTP** · 36×18 · @(64,0) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:HTTP** · 24×14 · @(6,2) · size H/H · «HTTP» Mono 500 10/14 text2
      - **t:Недоступен · 1 мин н** · 131×15 · @(0,20) · size H/H · «Недоступен · 1 мин назад» Manrope 400 11/15 danger
    - **Button/subtle** · 112×28 · @(214,12) · size H/F · row gap 8 pad 0 12 0 12 center/center · r 4
      - **icon/sync** · 16×16 · @(12,6) · size F/F · icon `arrow-sync-16.svg` accentText
      - **t:Проверить** · 64×17 · @(36,5.5) · size H/H · «Проверить» Manrope 500 12/17 accentText

</details>

## Current proxy pill

Единственная пилюля текущего прокси на главном экране (372×60, r 30). Default / Hover / Open (меню открыто) / Error (danger, «Не отвечает 40 с», «таймаут») / Empty (пунктир 4/4, «Прокси ещё нет», Ctrl+V).

- Figma Component Set: `73:1567` · Данные: [`layout/components/current_proxy_pill.json`](layout/components/current_proxy_pill.json) · Эталон: [`reference/components/current_proxy_pill.html`](../reference/components/current_proxy_pill.html)

| Вариант | Figma id | Размер |
|---|---|---|
| State=Default | `73:1568` | 372×60 |
| State=Hover | `73:1586` | 372×60 |
| State=Open | `73:1604` | 372×60 |
| State=Error | `73:1622` | 372×60 |
| State=Empty | `73:1637` | 372×60 |

<details><summary>Конспект вариантов</summary>

- **Current proxy pill** · 420×412 · @(0,0) · col gap 16 pad 24 24 24 24 start/start · bg bg · r 12
  - **State=Default** · 372×60 · @(24,24) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 1 stroke · r 30 · shadow shadow/pill
    - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
      - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
    - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
        - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
      - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
    - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
      - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
    - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **State=Hover** · 372×60 · @(24,100) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surfaceHover · border 1 strokeStrong · r 30 · shadow shadow/pill
    - **Badge** · 44×44 · @(9,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
      - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
    - **text** · 169×38 · @(63,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
        - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
      - **t:185.12.•••.7** · 169×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
    - **Ping** · 55×17 · @(242,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **Button/subtle** · 28×28 · @(307,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
      - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
    - **icon/chevron** · 16×16 · @(345,22) · size F/F · icon `chevron-down-16.svg` text2
  - **State=Open** · 372×60 · @(24,176) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 2 accent · r 30 · shadow shadow/pill
    - **Badge** · 44×44 · @(10,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p1 · r 22
      - **t:1** · 8×25 · @(18,9.5) · size H/H · «1» Manrope 700 18/25 onDark
    - **text** · 167×38 · @(64,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 121×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Германия** · 67×19 · @(0,0) · size H/H · «Германия» Manrope 600 14/19 text
        - **Chip/SOCKS5** · 48×18 · @(73,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:SOCKS5** · 36×14 · @(6,2) · size H/H · «SOCKS5» Mono 500 10/14 text2
      - **t:185.12.•••.7** · 167×17 · @(0,21) · size F/H · «185.12.•••.7» Mono 400 12/17 text3 1 строка…
    - **Ping** · 55×17 · @(241,21.5) · size H/H · row gap 6 pad 0 0 0 0 start/center
      - **PingBars** · 13×11 · @(0,3) · size H/F · row gap 2 pad 0 0 0 0 start/end
        - **bar** · 3×5 · @(0,6) · size F/F · bg success · r 1
        - **bar** · 3×8 · @(5,3) · size F/F · bg success · r 1
        - **bar** · 3×11 · @(10,0) · size F/F · bg success · r 1
      - **t:48 мс** · 36×17 · @(19,0) · size H/H · «48 мс» Mono 500 12/17 success
    - **Button/subtle** · 28×28 · @(306,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
      - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
    - **icon/chevron** · 16×16 · @(344,22) · size F/F · icon `chevron-down-16.svg` text2
  - **State=Error** · 372×60 · @(24,252) · size F/F · row gap 10 pad 0 10 0 8 start/center · bg surface · border 2 danger · r 30 · shadow shadow/pill
    - **Badge** · 44×44 · @(10,8) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg p3 · r 22
      - **t:3** · 11×25 · @(16.5,9.5) · size H/H · «3» Manrope 700 18/25 onDark
    - **text** · 151×38 · @(64,11) · size F/H · col gap 2 pad 0 0 0 0 start/start
      - **titleRow** · 136×19 · @(0,0) · size H/H · row gap 6 pad 0 0 0 0 start/center
        - **t:Нидерланды** · 88×19 · @(0,0) · size H/H · «Нидерланды» Manrope 600 14/19 text
        - **Chip/VLESS** · 42×18 · @(94,0.5) · size H/F · row gap 4 pad 0 5 0 5 center/center · bg control · border 1 stroke · r 4
          - **t:VLESS** · 30×14 · @(6,2) · size H/H · «VLESS» Mono 500 10/14 text2
      - **t:Не отвечает 40 с** · 151×17 · @(0,21) · size F/H · «Не отвечает 40 с» Mono 400 12/17 danger 1 строка…
    - **Ping/error** · 71×17 · @(225,21.5) · size H/H · row gap 4 pad 0 0 0 0 start/center
      - **icon/error** · 16×16 · @(0,0.5) · size F/F · icon `error-circle-16.svg` danger
      - **t:таймаут** · 51×17 · @(20,0) · size H/H · «таймаут» Mono 400 12/17 danger
    - **Button/subtle** · 28×28 · @(306,16) · size F/F · row gap 8 pad 0 0 0 0 center/center · r 4
      - **icon/copy** · 16×16 · @(6,6) · size F/F · icon `copy-16.svg` text2
    - **icon/chevron** · 16×16 · @(344,22) · size F/F · icon `chevron-down-16.svg` text2
  - **State=Empty** · 372×60 · @(24,328) · size F/F · row gap 12 pad 0 16 0 16 start/center · border 1 strokeStrong dashed · r 30
    - **icon/paste** · 20×20 · @(17,20) · size F/F · icon `clipboard-paste-20.svg` text2
    - **text** · 240×36 · @(49,12) · size F/H · col gap 0 pad 0 0 0 0 start/start
      - **t:Прокси ещё нет** · 108×19 · @(0,0) · size H/H · «Прокси ещё нет» Manrope 600 14/19 text
      - **t:Скопируйте ссылку — ** · 240×17 · @(0,19) · size F/H · «Скопируйте ссылку — она вставится сама» Manrope 400 12/17 text3 1 строка…
    - **Chip/Ctrl+V** · 54×20 · @(301,20) · size H/F · row gap 4 pad 0 6 0 6 center/center · bg control · border 1 stroke · r 4
      - **t:Ctrl+V** · 40×15 · @(7,2.5) · size H/H · «Ctrl+V» Mono 500 11/15 text2

</details>

## Proxy dot

Цветная точка прокси: p1 / p2 / p3 / Напрямую (кольцо text3). Размеры 8 и 10.

- Figma Component Set: `73:1469` · Данные: [`layout/components/proxy_dot.json`](layout/components/proxy_dot.json) · Эталон: [`reference/components/proxy_dot.html`](../reference/components/proxy_dot.html)

| Вариант | Figma id | Размер |
|---|---|---|
| Proxy=1, Size=8 | `73:1470` | 8×8 |
| Proxy=2, Size=8 | `73:1471` | 8×8 |
| Proxy=3, Size=8 | `73:1472` | 8×8 |
| Proxy=Напрямую, Size=8 | `73:1473` | 8×8 |
| Proxy=1, Size=10 | `73:1474` | 10×10 |
| Proxy=2, Size=10 | `73:1475` | 10×10 |
| Proxy=3, Size=10 | `73:1476` | 10×10 |
| Proxy=Напрямую, Size=10 | `73:1477` | 10×10 |

<details><summary>Конспект вариантов</summary>

- **Proxy dot** · 200×84 · @(0,0) · row gap 16 pad 24 24 24 24 start/start · bg bg · r 12
  - **Proxy=1, Size=8** · 8×8 · @(24,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 4
  - **Proxy=2, Size=8** · 8×8 · @(48,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p2 · r 4
  - **Proxy=3, Size=8** · 8×8 · @(72,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p3 · r 4
  - **Proxy=Напрямую, Size=8** · 8×8 · @(96,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.2 text3 · r 4
  - **Proxy=1, Size=10** · 10×10 · @(120,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p1 · r 5
  - **Proxy=2, Size=10** · 10×10 · @(146,24) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p2 · r 5
  - **Proxy=3, Size=10** · 10×10 · @(24,50) · size F/F · row gap 0 pad 0 0 0 0 start/center · bg p3 · r 5
  - **Proxy=Напрямую, Size=10** · 10×10 · @(50,50) · size F/F · row gap 0 pad 0 0 0 0 start/center · border 1.2 text3 · r 5

</details>

## Theme toggle

Кнопка темы в заголовке окна, 32×28: в светлой теме — луна, в тёмной — солнце. Default / Hover (subtleHover) / Focus (рамка 2 px text). Тултип — «Тёмная тема» / «Светлая тема».

- Figma Component Set: `73:1478` · Данные: [`layout/components/theme_toggle.json`](layout/components/theme_toggle.json) · Эталон: [`reference/components/theme_toggle.html`](../reference/components/theme_toggle.html)

| Вариант | Figma id | Размер |
|---|---|---|
| State=Default | `73:1479` | 32×28 |
| State=Hover | `73:1482` | 32×28 |
| State=Focus | `73:1485` | 32×28 |

<details><summary>Конспект вариантов</summary>

- **Theme toggle** · 176×76 · @(0,0) · row gap 16 pad 24 24 24 24 start/start · bg bg · r 12
  - **State=Default** · 32×28 · @(24,24) · size F/F · row gap 0 pad 0 0 0 0 center/center · r 4
    - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
    - **icon/sun** · 16×16 · @(16,6) · size F/F · hidden · icon `weather-sunny-16.svg` text2
  - **State=Hover** · 32×28 · @(72,24) · size F/F · row gap 0 pad 0 0 0 0 center/center · bg subtleHover · r 4
    - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
    - **icon/sun** · 16×16 · @(16,6) · size F/F · hidden · ⟨Weather Sunny / Size=16, Theme=Regular⟩
  - **State=Focus** · 32×28 · @(120,24) · size F/F · row gap 0 pad 0 0 0 0 center/center · border 2 text · r 4
    - **icon/moon** · 16×16 · @(8,6) · size F/F · icon `weather-moon-16.svg` text2
    - **icon/sun** · 16×16 · @(16,6) · size F/F · hidden · ⟨Weather Sunny / Size=16, Theme=Regular⟩

</details>

## App icon

Иконки приложений 24×24 (многоцветные SVG в assets/icons/app-*.svg). В продукте — реальная иконка .exe (извлекается бэкендом), эти — для макета/заглушки.

- Figma Component Set: `73:1450` · Данные: [`layout/components/app_icon.json`](layout/components/app_icon.json) · Эталон: [`reference/components/app_icon.html`](../reference/components/app_icon.html)

| Вариант | Figma id | Размер |
|---|---|---|
| App=Chrome | `73:1451` | 24×24 |
| App=Telegram | `73:1457` | 24×24 |
| App=Dolphin Anty | `73:1460` | 24×24 |
| App=Discord | `73:1464` | 24×24 |

<details><summary>Конспект вариантов</summary>

- **App icon** · 192×72 · @(0,0) · row gap 16 pad 24 24 24 24 start/start · bg bg · r 12
  - **App=Chrome** · 24×24 · @(24,24) · size F/F · icon `app-chrome.svg` 
  - **App=Telegram** · 24×24 · @(64,24) · size F/F · icon `app-telegram.svg` 
  - **App=Dolphin Anty** · 24×24 · @(104,24) · size F/F · icon `app-dolphin-anty.svg` 
  - **App=Discord** · 24×24 · @(144,24) · size F/F · icon `app-discord.svg` 

</details>

## Row menu (⋯)

Меню строки: Приостановить («идёт напрямую, пока не включите») · Пустить напрямую («только в режиме «Всё остальное → через прокси»») · Убрать из списка (danger). Других пунктов нет.

- Figma Component Set: `73:1432` · Данные: [`layout/components/row_menu.json`](layout/components/row_menu.json) · Эталон: [`reference/components/row_menu.html`](../reference/components/row_menu.html)

| Вариант | Figma id | Размер |
|---|---|---|
| MenuItem/Приостановить | `73:1433` | 250×48 |
| MenuItem/Пустить напрямую | `73:1439` | 250×48 |
| MenuItem/Убрать из списка | `73:1445` | 250×36 |

<details><summary>Конспект вариантов</summary>

- **⋯ Row menu (пример)** · 260×146 · @(0,0) · col gap 2 pad 4 4 4 4 start/start · bg flyout · border 1 stroke · r 8 · shadow shadow/flyout
  - **MenuItem/Приостановить** · 250×48 · @(5,5) · size F/F · row gap 10 pad 0 10 0 12 start/center · r 4
    - **icon/subtract** · 16×16 · @(12,16) · size F/F · icon `subtract-16.svg` text2
    - **box** · 202×34 · @(38,7) · size F/H · col gap 1 pad 0 0 0 0 start/start
      - **t:Приостановить** · 96×18 · @(0,0) · size H/H · «Приостановить» Manrope 400 13/18 text
      - **t:идёт напрямую, пока ** · 202×15 · @(0,19) · size F/H · «идёт напрямую, пока не включите» Manrope 400 11/15 text3
  - **MenuItem/Пустить напрямую** · 250×48 · @(5,55) · size F/F · row gap 10 pad 0 10 0 12 start/center · r 4
    - **icon/arrow** · 16×16 · @(12,16) · size F/F · icon `arrow-right-16.svg` text2
    - **box** · 202×49 · @(38,-0.5) · size F/H · col gap 1 pad 0 0 0 0 start/start
      - **t:Пустить напрямую** · 117×18 · @(0,0) · size H/H · «Пустить напрямую» Manrope 400 13/18 text
      - **t:только в режиме «Всё** · 202×30 · @(0,19) · size F/H · «только в режиме «Всё остальное → через прокси»» Manrope 400 11/15 text3
  - **MenuItem/Убрать из списка** · 250×36 · @(5,105) · size F/F · row gap 10 pad 0 10 0 12 start/center · r 4
    - **icon/del** · 16×16 · @(12,10) · size F/F · icon `delete-16.svg` danger
    - **box** · 202×18 · @(38,9) · size F/H · col gap 1 pad 0 0 0 0 start/start
      - **t:Убрать из списка** · 107×18 · @(0,0) · size H/H · «Убрать из списка» Manrope 400 13/18 danger

</details>
