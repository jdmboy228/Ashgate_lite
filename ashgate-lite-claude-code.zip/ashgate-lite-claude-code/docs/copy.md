# Тексты интерфейса (copy)

Все видимые строки из макета (автоизвлечение из `docs/layout`, `python3 tools/gen_docs.py`). Колонка «Где» — буквы экранов a–l или имя компонента. Значения вроде «Германия», «185.12.•••.7», «48 мс», «↓ 1,4 МБ/с» — **пример данных**, в продукте подставляются из бэкенда (см. [bridge-api.md](bridge-api.md)); шаблоны — в разделе ниже.

| Строка | Где |
|---|---|
| Ashgate Lite | a, b, c, d, f, g, h, i, j, l |
| Пока всё идёт напрямую | a, l |
| Скопируйте ссылку прокси — и выберите приложения | a |
| Прокси ещё нет | a, current_proxy_pill |
| Скопируйте ссылку — она вставится сама | a, current_proxy_pill |
| Ctrl+V | a, current_proxy_pill |
| Найдено на этом ПК | a |
| Chrome | a, b, c, d, g, h, i, j, l, app_row |
| запущено | a |
| Telegram | a, b, c, d, g, h, i, l, app_row |
| Dolphin Anty | a, b, c, d, f, g, h, i, j, l, app_row |
| Пуск | a, f |
| Discord | a, b, d, i, l, app_row |
| Всё остальное → | a, b, c, d, g, h, i, j, l, footer_switch |
| напрямую | a, b, d, g, h, i, l, footer_switch |
| 4 приложения идут через прокси | b, d, h, i |
| 2 работают · 1 не запущено · 1 с ошибкой | b, d |
| 1 | b, c, d, g, h, i, j, l, current_proxy_pill |
| Германия | b, c, d, g, h, i, j, l, current_proxy_pill |
| SOCKS5 | b, c, d, e, g, h, i, j, l, current_proxy_pill, proxy_menu_item |
| 185.12.•••.7 | b, c, d, h, i, j, l, current_proxy_pill |
| 48 мс | b, c, d, e, h, i, j, l, current_proxy_pill, proxy_menu_item |
| Приложения | b, c, d, g, h, i, j, l |
| Добавить | b, c, d, f, g, h, i, j, l |
| ↓ 1,4 МБ/с   ↑ 120 КБ/с | b, c, d, h, i, j, app_row |
| Работает | b, c, d, h, i, j, app_row |
| ↓ 860 КБ/с   ↑ 64 КБ/с | b, c, d, h, i, j, app_row |
| Запустите — пойдёт через прокси | b, d, f, g, h, i, app_row |
| Не запущено | b, d, f, g, h, i, app_row |
| Соединения не проходят | b, d, app_row |
| Ошибка | b, d, app_row |
| Прокси 1 не пропускает UDP — звонки не работают. | b, d, app_row |
| Проверить снова | b, d, e, g, app_row, retry_button |
| Весь трафик → Прокси 1 | c, j |
| Все приложения Windows · SOCKS5 · Германия | c, j |
| Все приложения Windows | c, j |
| ↓ 4,4 МБ/с   ↑ 494 КБ/с | c, j |
| Сейчас не влияет — через прокси идёт весь трафик | c, j |
| не запущено | c, l |
| Прокси упадёт — интернет на паузе, IP не утечёт | c, j, footer_switch |
| через Прокси 1 | c, j, footer_switch |
| Текущий прокси | d |
| пинг сейчас | d |
| Прокси 1 | d, e, k, proxy_menu_item |
| Германия · 185.12.•••.7 | d, proxy_menu_item |
| Прокси 2 | d, e, proxy_menu_item |
| HTTP | d, e, proxy_menu_item |
| Недоступен · 1 мин назад | d, proxy_menu_item |
| Проверить | d, proxy_menu_item |
| Прокси 3 | d, e |
| VLESS | d, e, current_proxy_pill |
| быстрый | d |
| Нидерланды · nl-ams.•••.net | d |
| 64 мс | d, e, g |
| Напрямую | d |
| Без прокси — сайты видят ваш IP | d |
| Управление прокси… | d |
| Ctrl+P | d |
| Управление прокси — Ashgate Lite | e, k |
| Прокси | e |
| 3 из 3 | e |
| Проверить все | e |
| 3 из 3 — удалите прокси, чтобы вставить новый | e |
| текущий | e, k |
| Германия · 185.12.•••.7:1080 | e |
| таймаут | e, g, current_proxy_pill, proxy_menu_item |
| США · 91.204.•••.33:8080 | e |
| Прокси 2 не отвечает уже 1 мин | e |
| Нидерланды · nl-ams.•••.net:443 | e |
| Ссылку можно вставить в любом окне — Ctrl+V | e |
| Готово | e |
| Добавить приложение | f |
| dolph | f |
| Найдено 3 | f |
| C:\Users\Admin\AppData\Local\Programs\Dolphin Anty\Dolphin Anty.exe | f |
| Запущено | f |
| Dolphin Anty Beta | f |
| C:\Program Files\Dolphin Anty Beta\dolphin_anty.exe | f |
| Program Files | f |
| Dolphin Updater | f |
| C:\Users\Admin\AppData\Local\Dolphin\updater.exe | f |
| Так оно появится в списке: | f |
| Enter | f |
| Прокси 1 не отвечает | g |
| Приложения на паузе — IP не утёк | g |
| Не отвечает 40 с | g, current_proxy_pill |
| Быстрее всех: Прокси 3 · Нидерланды | g |
| Переключиться на быстрейший | g |
| На паузе — ждём прокси | g |
| Проверяем… | g, i, app_row, retry_button |
| 2 работают · 1 не запущено | h |
| Проверяем Discord… | i |
| Проверяем соединение через Прокси 1… | i |
| Ссылка прокси | k |
| socks5://185.12.•••.7:1080 | k |
| Удалить | k |
| Отмена | k |
| Сохранить | k |
| Выключено · включите, чтобы пустить через прокси | l |
| идёт напрямую | l |
| 3 | current_proxy_pill |
| Нидерланды | current_proxy_pill |
| Приостановить | row_menu |
| идёт напрямую, пока не включите | row_menu |
| Пустить напрямую | row_menu |
| только в режиме «Всё остальное → через прокси» | row_menu |
| Убрать из списка | row_menu |

## Шаблоны динамических строк

| Ключ | Шаблон | Пример из макета |
|---|---|---|
| `hero.off` | Пока всё идёт напрямую | a, l |
| `hero.apps` | {n} {приложение/приложения/приложений} идут через прокси | «4 приложения идут через прокси» |
| `hero.all` | Весь трафик → Прокси {N} | c, j |
| `hero.down` | Прокси {N} не отвечает | g |
| `sub.first` | Скопируйте ссылку прокси — и выберите приложения | a |
| `sub.off` | Выключено · включите, чтобы пустить через прокси | l |
| `sub.summary` | {k} работают · {m} не запущено · {e} с ошибкой (нулевые части опускаются) | b, h |
| `sub.all` | Все приложения Windows · {TYPE} · {Страна} | c |
| `sub.down` | Приложения на паузе — IP не утёк | g |
| `sub.checking` | Проверяем {App}… | i |
| `row.speed` | ↓ {down}   ↑ {up} (три пробела между частями; КБ/с, МБ/с, запятая) | «↓ 1,4 МБ/с   ↑ 120 КБ/с» |
| `row.notRunning` | Запустите — пойдёт через прокси | b |
| `row.paused` | На паузе — ждём прокси | g |
| `row.direct` | идёт напрямую (запущено, переключатель выкл) / не запущено | l |
| `row.checking` | Проверяем соединение через Прокси {N}… | i |
| `ping` | {ms} мс | «48 мс» |
| `pill.down` | Не отвечает {sec} с | «Не отвечает 40 с» |
| `menu.unavailable` | Недоступен · {N} мин назад | d |
| `manage.limit` | {k} из 3 | e |
| `manage.down` | Прокси {N} не отвечает уже {N} мин | e |
| `edit.title` | Прокси {N} | k |
| `suggest.fastest` | Быстрее всех: Прокси {N} · {Страна} | g |
| `footer.target` | напрямую / через Прокси {N} | b / c |
| `found` | Найдено {n} | f |

Склонение «приложение»: 1 приложение, 2–4 приложения, 5+ приложений (с учётом 11–14).
