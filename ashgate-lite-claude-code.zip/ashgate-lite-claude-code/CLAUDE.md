# CLAUDE.md — Ashgate Lite UI: перенос макета в код 1:1

Ты переносишь UI **Ashgate Lite** из Figma в код. Ashgate — Windows-клиент per-app прокси: бэкенд на Go (WinDivert, Xray VLESS), фронтенд в WebView2 (HTML/CSS/JS).

**Lite — отдельная сборка.** Это отдельная ветка `lite` и отдельный exe (например, `ashgate-lite.exe`). Версию 0.5.2 и её UI **не трогать и не заменять**.

## Главное правило: 1:1 по данным, а не «на глаз»

1. **Источник истины** — `docs/layout/*.json` (полное дерево каждого экрана и варианта компонента) и `tokens/tokens.css` / `tokens/tokens.json`.
   - Размеры, отступы, gap, выравнивание, радиусы, цвета, шрифты и тексты бери **оттуда**.
   - Значения не угадывай, не округляй и не «улучшай».
2. **Переиспользуй эталонную вёрстку** `reference/`. Это рабочий HTML/CSS всех экранов a–l в обеих темах, сгенерированный из тех же JSON и проверенный попиксельно против Figma. Смотри [таблицу диффа](#проверка).
   - Структуру DOM, flex-правила и размеры переноси из `reference/screens/*.html` в компоненты приложения.
   - В reference всё лежит inline-стилями по узлам. В продукте вынеси повторяющееся в классы (`.app-row`, `.pill`, …), но **значения оставь те же**.
3. **PNG** (`design/`) — только для финальной визуальной сверки. Не измеряй по ним.
4. **Перед тем как считать экран готовым**, прогони `tools/pixel_diff.py` против своего рендера и держи дифф в пороге:
   - strict ≤ **2.0 %**;
   - structural (±1 px) ≤ **0.5 %**. Для экранов без фиксации ширин текста допустимо до 0.6 %.
5. **Не добавляй функций, экранов, пунктов меню, настроек и анимаций**, которых нет в макете и в [docs/behavior.md](docs/behavior.md). Если чего-то не хватает, запиши вопрос, а не придумывай. Открытые вопросы перечислены в конце behavior.md.

## Что где лежит

| Путь | Что это |
|---|---|
| `docs/layout/<экран>.json` | Полное дерево узла-кадра: type, x/y/width/height, layout (direction, gap, padding, justify, align, wrap), sizing (fixed/hug/fill), absolute, fills/strokes/effects (токен + hex light/dark), cornerRadius, text (content, шрифт, вес, размер, интерлиньяж, цвет-токен, выравнивание, обрезка), icon (файл SVG, токен цвета) |
| `docs/layout/components/*.json` | То же для каждого Component Set и всех его вариантов |
| `docs/screens.md` / `docs/components.md` | Читаемые конспекты тех же деревьев + описание экранов/вариантов |
| `docs/behavior.md` | Поведение, состояния, переходы, горячие клавиши, тема, kill switch, открытые вопросы |
| `docs/copy.md` | Все тексты интерфейса и шаблоны динамических строк |
| `docs/bridge-api.md` | Контракт Go ↔ JS: команды, события, типы, `settings.json` |
| `docs/mock-states.json` | Моковые `State` для каждого экрана a–l (для `?mock=` и pixel diff) |
| `tokens/tokens.css` | CSS-переменные: `:root` (светлая) + `[data-theme="dark"]`, отступы, радиусы, тени, шрифты |
| `tokens/tokens.json` | Те же токены машинно-читаемо (+ типографика, размеры окон, имя Figma-переменной) |
| `reference/` | Эталонная вёрстка: `index.html` (галерея), `screens/*.html`, `components/*.html`, `reference.css` |
| `assets/icons/*.svg` | Все иконки (Fluent, `currentColor`; приложения — многоцветные) — см. `assets/icons/README.md` |
| `assets/fonts/` | Manrope (variable) и IBM Plex Mono 400/500/600 + лицензии OFL — см. `assets/fonts/README.md` |
| `design/light`, `design/dark` | PNG 2x с тенью окна — для глаз |
| `design/frame-only/<тема>/` | PNG 2x без тени — эталон для `pixel_diff.py` |
| `tools/` | `pixel_diff.py` (сверка), `gen_reference.py`, `normalize_layout.py`, `gen_docs.py`, `outline.py`, `figma/` (скрипт выгрузки и сырой дамп) |

## Как читать layout JSON → CSS

Это те же правила, по которым сделан `tools/gen_reference.py`. При сомнении смотри этот файл.

- `layout.direction` → `display:flex; flex-direction: row|column`; `gap`; `padding` (top right bottom left).
- `justify`: start/center/end/space-between → `justify-content`. `align`: start/center/end/baseline → `align-items`.
- `sizing` по главной оси родителя:
  - `fixed` → размер в px + `flex:none`;
  - `fill` → `flex:1 1 0; min-width:0` (или min-height);
  - `hug` → `flex:none`, размер по содержимому.
- `sizing` по поперечной оси: `fill` → `align-self:stretch`.
- `absolute: true` → `position:absolute; left:x; top:y` относительно родителя (родитель `position:relative`).
- `x/y` указаны относительно родителя. В auto-layout они вычисляются сами и нужны для проверки.
- `fills[].token` → `var(--color-<token>)`. `opacity` у заливки — альфа цвета. `opacity` у узла — `opacity`.
- `strokes` + `strokeWeight` + `strokeAlign`:
  - INSIDE → рамка внутрь, `box-shadow: inset` или `border` с `box-sizing:border-box`;
  - `dashPattern` → пунктир (в reference это SVG-rect с `stroke-dasharray`).
- `effects` DROP_SHADOW → `var(--shadow-window|flyout|pill)` из tokens.css.
- `text`:
  - `font: <weight> <size>px/<lineHeight>px var(--font-ui|--font-mono)`;
  - `color: var(--color-…)`;
  - `textAlign`;
  - `truncate`/`maxLines:1` → `white-space:nowrap; overflow:hidden; text-overflow:ellipsis`;
  - несколько пробелов подряд в тексте значимы (`white-space:pre`).
- `icon.file` → инлайн SVG из `assets/icons/`, цвет — `color: var(--color-<icon.colorToken>)`. `themeSwap` означает, что луна показывается только в светлой теме, солнце — только в тёмной.
- `hidden: true` → узел не рендерится. Это скрытые слои вариантов, например тег «быстрый».

## Порядок работы

1. Создай ветку `lite` от актуальной ветки. Отдельная точка входа (`cmd/ashgate-lite`) и отдельная папка UI (например, `ui-lite/`), чтобы сборка 0.5.2 не менялась.
2. Скопируй в `ui-lite/` файлы `tokens/tokens.css`, `assets/fonts/*`, `assets/icons/*`. Подключи шрифты через `@font-face` локально, как в `reference/reference.css`, без CDN.
3. Каркас окна: TitleBar 32 px (drag-region, тема, свернуть, закрыть), окно 420×640, минимум 360×520, радиус 8, рамка `winStroke`. Окно «Управление прокси» — 420×560.
4. Компоненты по `docs/layout/components/*.json`, сверяясь с `reference/components/*.html`:
   - Proxy dot → Theme toggle → Retry button → Current proxy pill → Proxy menu item → App row → Row menu → Footer switch.
5. Экраны: b → l → c → d → g → i → a → f → e → k → h/j.
   - l — тот же экран b в выключенном состоянии; k — второе состояние окна e.
   - h/j — тот же экран b/c при ширине 360. Отдельной вёрстки нет, работают те же flex-правила.
6. Мост `docs/bridge-api.md` и моки `docs/mock-states.json`. Режим `?mock=<frame>&theme=<light|dark>` рендерит ровно состояние экрана из макета: hover, раскрытая ошибка и открытое меню задаются через `ui`.
7. Поведение по `docs/behavior.md`: состояния, Retry, ⋯-меню, футер и режим «весь трафик», kill switch, тема, горячие клавиши.
8. Проверка (см. ниже) для **всех 12 экранов × 2 темы**.

## Проверка

```bash
pip install pillow numpy          # + установлен Chrome/Chromium/Edge (или задайте CHROME=путь)
# 1) эталон reference против Figma (должно быть OK везде)
python3 tools/pixel_diff.py
# 2) твоя реализация против Figma (каждый экран отдельно; страница должна рендерить кадр без тени, размер окна = размер кадра)
python3 tools/pixel_diff.py --html "http://localhost:5173/?mock=b_glavnaya" --frame b_glavnaya --tol-threshold 0.6
# 3) на Windows шрифты растеризуются иначе (ClearType) → сравнивай с рендером reference этим же браузером:
python3 tools/pixel_diff.py --html "http://localhost:5173/?mock=b_glavnaya" --frame b_glavnaya --against reference
```

- К URL автоматически добавляется `theme=light|dark`. Без `--theme` проверяются обе темы.
- Карта отличий сохраняется в `tools/out/<frame>_<theme>_diff.png`, отчёт — в `tools/out/report.json`.
- Если дифф выше порога, открой `_diff.png`, найди узел в layout JSON и исправь значение. Не подгоняй порог.

Результат reference против Figma (2x, обе темы, `tools/out/report.json`):

| Экран | strict light / dark | structural light / dark |
|---|---|---|
| a | 0.828 / 0.853 % | 0.074 / 0.103 % |
| b | 1.063 / 1.067 % | 0.020 / 0.044 % |
| c | 0.953 / 0.967 % | 0.012 / 0.034 % |
| d | 1.040 / 1.025 % | 0.015 / 0.042 % |
| e | 1.264 / 1.241 % | 0.024 / 0.024 % |
| f | 0.811 / 0.805 % | 0.017 / 0.034 % |
| g | 1.009 / 1.026 % | 0.082 / 0.096 % |
| h | 1.373 / 1.381 % | 0.023 / 0.058 % |
| i | 0.962 / 0.963 % | 0.017 / 0.040 % |
| j | 1.309 / 1.329 % | 0.017 / 0.048 % |
| k | 0.598 / 0.600 % | 0.037 / 0.035 % |
| l | 0.748 / 0.768 % | 0.007 / 0.035 % |

Остаток strict (~1 %) — это сглаживание краёв шрифтов и SVG, а не ошибка вёрстки.
- В a остаток structural — фаза пунктира и центрирование обрезанного подзаголовка.
- В reference ширины hug-текстов зафиксированы по Figma (`--fw`, класс `lock-text`). **В продукте ширины текстов не фиксировать**: строки динамические. Без фиксации (`?lock=0`) structural ≤ 0.48 %.

## Жёсткие правила реализации

- **Только токены.** Ни одного hex в CSS компонентов: всё через `var(--color-*)`, `--space-*`, `--radius-*`, `--shadow-*`, `--font-*`. Если нужного токена нет, бери значение из layout JSON как есть и пометь комментарием.
- **Тема.** `data-theme` на `<html>`. Первый запуск — светлая. Тему Windows **не читать**, `prefers-color-scheme` не использовать. Выбор хранится в `settings.json` как `theme=light|dark` и применяется до первой отрисовки.
- **Контраст.** `success` в светлой теме — `#117C47` (в tokens и в Figma; старое `#12804A` давало 4.42:1 и не проходило AA). Пилюля «Работает» должна давать ≥ 4.5:1.
- **Шрифты.** Manrope — UI, IBM Plex Mono — адреса, пинг, скорость, `Ctrl+V`. Нужны локальные файлы и `font-feature-settings` по умолчанию.
- **Заголовок героя — всегда одна строка** при ширине от 360 до 420 px. Бери Bold 18/25 из layout JSON.
- **Производительность.** Скорости обновлять не чаще 1 раза в секунду и только текст (без перестройки DOM). Без фреймворков: vanilla HTML/CSS/JS, ES-модули. Анимации — только transform/opacity ≤ 150 мс. При `prefers-reduced-motion` — без анимаций.
- **Клавиатура и фокус.** Всё доступно с клавиатуры. Фокус видим (рамка 2 px `--color-text`, как Theme toggle/Focus). Горячие клавиши: Ctrl+V, Ctrl+P, Enter, Esc, ↑/↓.
- **Строка приложения** не даёт выбрать прокси для отдельного приложения. Раскрытая ошибка содержит только «Проверить снова». ⋯-меню содержит ровно 3 пункта.
- Прокси не больше 3. Текущий — один. Отдельного выбора прокси для приложения нет.

## Как обновить данные из Figma (если макет изменится)

Файл Figma `ivKd4DHFJo86jSyDETbeQh`, страница `73:61`. Скрипт выгрузки — `tools/figma/dump.js` (для Figma Plugin API / MCP `use_figma`). Сырой результат сохраняется в `tools/figma/raw_dump.json`, затем:

```bash
python3 tools/normalize_layout.py && python3 tools/gen_reference.py && python3 tools/gen_docs.py && python3 tools/pixel_diff.py
```
