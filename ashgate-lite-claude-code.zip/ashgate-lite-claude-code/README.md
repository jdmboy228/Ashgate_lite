# Ashgate Lite — пакет передачи UI/UX в код (для Claude Code)

В пакете всё, что нужно, чтобы перенести UI **Ashgate Lite** из Figma в код (Go + WebView2, HTML/CSS/JS) **1:1 по точным данным**:

- полные деревья всех экранов и компонентов в JSON;
- токены;
- готовая эталонная вёрстка, проверенная попиксельно;
- иконки и шрифты;
- поведение, тексты, контракт моста Go ↔ JS;
- скрипт сверки.

Lite — **отдельная сборка**: ветка `lite`, свой exe. Версию 0.5.2 она не заменяет.

## Как пользоваться

1. Распакуй архив в корень репозитория Ashgate, например в `design/lite-handoff/`, или рядом с ним.
2. Если папка лежит внутри репозитория, перенеси `CLAUDE.md` в корень репозитория или сошлись на него из корневого `CLAUDE.md`: `См. design/lite-handoff/CLAUDE.md`. Claude Code сам читает `CLAUDE.md`.
3. Посмотри эталон: открой `reference/index.html` в браузере. Там все экраны a–l и компоненты, переключатель темы.
4. Поставь зависимости для сверки: Python 3, `pip install pillow numpy`, Chrome или Edge.
5. Запусти Claude Code в репозитории и дай первый промпт из примеров ниже.

## Примеры первых промптов

**Старт (план):**
> Прочитай design/lite-handoff/CLAUDE.md и все файлы в docs/. Ничего не пиши в код. Составь план переноса UI Ashgate Lite в отдельную ветку `lite` с отдельным exe: структура папок ui-lite/, точка входа cmd/ashgate-lite, порядок компонентов и экранов, как будешь проверять pixel_diff. Отметь всё, что неясно (см. «Открытые вопросы» в docs/behavior.md).

**Каркас + токены:**
> Создай ветку lite. Сделай каркас ui-lite/: подключи tokens/tokens.css, локальные шрифты и иконки из пакета, окно 420×640 (мин. 360×520) с TitleBar 32 px и ручным переключателем темы (data-theme, settings.json theme=light|dark, первый запуск светлый, тему Windows не читать). Добавь режим ?mock=<frame>&theme=… на основе docs/mock-states.json.

**Компоненты 1:1:**
> Реализуй компоненты App row, Current proxy pill, Proxy menu item, Retry button, Footer switch, Row menu, Theme toggle, Proxy dot. Значения бери только из docs/layout/components/*.json и tokens, разметку переноси из reference/components/*.html. Никаких новых вариантов и функций.

**Экран + сверка:**
> Собери экран b_glavnaya по docs/layout/b_glavnaya.json и reference/screens/b_glavnaya.html. Запусти `python3 tools/pixel_diff.py --html "http://localhost:5173/?mock=b_glavnaya" --frame b_glavnaya --tol-threshold 0.6` для обеих тем и правь, пока strict ≤ 2 % и structural ≤ 0.6 %. Покажи таблицу результатов.

**Поведение и мост:**
> Реализуй docs/bridge-api.md: JS-клиент моста и Go-обработчики-заглушки. Затем поведение из docs/behavior.md: выбор прокси (≤3, один текущий, пинг при открытии меню, недоступные приглушены), Retry → «Проверяем…», ⋯-меню из 3 пунктов, футер «Всё остальное →» и режим «весь трафик», kill switch (экран g). Ничего сверх документа.

**Финальная проверка:**
> Прогони pixel_diff по всем 12 экранам × 2 темы на mock-состояниях и приложи tools/out/report.json. Затем сверь глазами с design/light и design/dark и перечисли расхождения, если есть.

## Состав

```
CLAUDE.md                инструкция для Claude Code (источник истины, правила, порядок, проверка)
README.md                этот файл
tokens/                  tokens.css (:root светлая + [data-theme=dark]) · tokens.json
docs/
  layout/*.json          полное дерево каждого экрана a–l
  layout/components/     полное дерево каждого компонента и всех вариантов
  screens.md · components.md · behavior.md · copy.md · bridge-api.md · mock-states.json
reference/               эталонная HTML/CSS-вёрстка: index.html, screens/, components/, reference.css
design/                  PNG 2x: light/, dark/ (с тенью), frame-only/ (эталон сверки), components.png, tokens.png
assets/icons/            SVG-иконки (+ README со списком)
assets/fonts/            Manrope, IBM Plex Mono + OFL (+ README со ссылками)
tools/                   pixel_diff.py, генераторы, figma/ (скрипт выгрузки + сырой дамп), out/report.json
```

Источник: Figma `ivKd4DHFJo86jSyDETbeQh`, страница «Ashgate Lite» (`73:61`).
