# Иконки

Источник: компоненты Figma (Fluent UI System Icons, Regular; лицензия MIT — https://github.com/microsoft/fluentui-system-icons). Монохромные SVG используют `currentColor`, поэтому цвет задаёт токен родителя: `color: var(--color-<токен>)`. Иконки `app-*` многоцветные и служат заглушками: в продукте показывается реальная иконка .exe. `ashgate-logo.svg` использует `var(--color-accent)` и `var(--color-onAccent)`.

В layout JSON у узла с иконкой есть поле `icon`: `{file, figmaComponent, colorToken, themeSwap}`.

| Файл | Компонент Figma | Токены цвета | Где |
|---|---|---|---|
| [`add-16.svg`](add-16.svg) | Add / Size=16, Theme=Regular | accentText, text | a, b, c, d, g, h, i, j |
| [`app-chrome.svg`](app-chrome.svg) | App icon / App=Chrome, App=Chrome | — | a, app_icon, app_row, b, c, d, g, h, i, j |
| [`app-discord.svg`](app-discord.svg) | App icon / App=Discord, App=Discord | — | a, app_icon, app_row, b, d, i |
| [`app-dolphin-28.svg`](app-dolphin-28.svg) | app/dolphin | — | f |
| [`app-dolphin-anty.svg`](app-dolphin-anty.svg) | App icon / App=Dolphin Anty, App=Dolphin Anty | — | a, app_icon, app_row, b, c, d, f, g, h, i, j |
| [`app-telegram.svg`](app-telegram.svg) | App icon / App=Telegram, App=Telegram | — | a, app_icon, app_row, b, c, d, g, h, i |
| [`apps-16.svg`](apps-16.svg) | Apps / Size=16, Theme=Regular | text2 | f |
| [`arrow-right-16.svg`](arrow-right-16.svg) | Arrow Right / Size=16, Theme=Regular | text2 | row_menu |
| [`arrow-sync-12.svg`](arrow-sync-12.svg) | Arrow Sync / Size=12, Theme=Regular | text2 | app_row, g, i |
| [`arrow-sync-16.svg`](arrow-sync-16.svg) | Arrow Sync / Size=16, Theme=Regular | accentText, onAccent, text, text2 | app_row, b, d, e, g, proxy_menu_item, retry_button |
| [`ashgate-logo.svg`](ashgate-logo.svg) | Ashgate logo | — | a, b, c, d, f, g, h, i, j |
| [`checkmark-circle-12.svg`](checkmark-circle-12.svg) | Checkmark Circle / Size=12, Theme=Regular | success | app_row, b, c, d, h, i, j |
| [`checkmark-circle-16.svg`](checkmark-circle-16.svg) | Checkmark Circle / Size=16, Theme=Regular | accentText | d, proxy_menu_item |
| [`chevron-down-12.svg`](chevron-down-12.svg) | Chevron / Direction=Down, Size=12, Theme=Regular | text2 | a, b, c, d, footer_switch, g, h, i, j |
| [`chevron-down-16.svg`](chevron-down-16.svg) | Chevron / Direction=Down, Size=16, Theme=Regular | text2 | b, c, current_proxy_pill, d, g, h, i, j |
| [`chevron-up-16.svg`](chevron-up-16.svg) | Chevron / Direction=Up, Size=16, Theme=Regular | text | f |
| [`clipboard-paste-20.svg`](clipboard-paste-20.svg) | Clipboard Paste / Size=20, Theme=Regular | text2 | a, current_proxy_pill |
| [`copy-16.svg`](copy-16.svg) | Copy / Size=16, Theme=Regular | text2 | b, c, current_proxy_pill, d, e, g, h, i, j |
| [`delete-16.svg`](delete-16.svg) | Delete / Size=16, Theme=Regular | danger | e, row_menu |
| [`dismiss-16.svg`](dismiss-16.svg) | Dismiss / Size=16, Theme=Regular | text2 | a, b, c, d, e, f, g, h, i, j |
| [`edit-16.svg`](edit-16.svg) | Edit / Size=16, Theme=Regular | text2 | e |
| [`error-circle-12.svg`](error-circle-12.svg) | Error Circle / Size=12, Theme=Regular | onAccent | app_row, b, d |
| [`error-circle-16.svg`](error-circle-16.svg) | Error Circle / Size=16, Theme=Regular | danger | current_proxy_pill, e, g, proxy_menu_item |
| [`flash-16.svg`](flash-16.svg) | Flash / Size=16, Theme=Regular | success | g |
| [`folder-open-16.svg`](folder-open-16.svg) | Folder Open / Size=16, Theme=Regular | text2 | f |
| [`globe-16.svg`](globe-16.svg) | Globe / Size=16, Theme=Regular | accentText, text2 | a, b, c, d, footer_switch, g, h, i, j |
| [`lock-closed-16.svg`](lock-closed-16.svg) | Lock Closed / Size=16, Theme=Regular | text2 | e |
| [`more-vertical-16.svg`](more-vertical-16.svg) | More Vertical / Size=16, Theme=Regular | text2 | app_row, b |
| [`search-16.svg`](search-16.svg) | Search / Size=16, Theme=Regular | text | f |
| [`settings-16.svg`](settings-16.svg) | Settings / Size=16, Theme=Regular | text2 | d, e |
| [`shield-globe-16.svg`](shield-globe-16.svg) | Shield Globe / Size=16, Theme=Regular | text3 | c, footer_switch, j |
| [`subtract-16.svg`](subtract-16.svg) | Subtract / Size=16, Theme=Regular | text2 | a, b, c, d, f, g, h, i, j, row_menu |
| [`weather-moon-16.svg`](weather-moon-16.svg) | Weather Moon / Size=16, Theme=Regular | text2 | a, b, c, d, e, f, g, h, i, j, theme_toggle |
| [`weather-sunny-16.svg`](weather-sunny-16.svg) | Weather Sunny / Size=16, Theme=Regular | text2 | theme_toggle |
| [`window-20.svg`](window-20.svg) | Window / Size=20, Theme=Regular | text2 | f |
