# Шрифты

| Шрифт | Где используется | Файлы здесь | Источник | Лицензия |
|---|---|---|---|---|
| **Manrope** (variable, wght 200–800; в макете 400/500/600/700) | весь UI | `Manrope-VariableFont_wght.ttf` | https://fonts.google.com/specimen/Manrope · https://github.com/google/fonts/tree/main/ofl/manrope | SIL OFL 1.1, [`OFL-Manrope.txt`](OFL-Manrope.txt) |
| **IBM Plex Mono** 400 / 500 / 600 | адреса прокси, пинг, скорость ↓/↑, пути .exe, `Ctrl+V` | `IBMPlexMono-Regular.ttf`, `IBMPlexMono-Medium.ttf`, `IBMPlexMono-SemiBold.ttf` | https://fonts.google.com/specimen/IBM+Plex+Mono · https://github.com/IBM/plex | SIL OFL 1.1, [`OFL-IBMPlexMono.txt`](OFL-IBMPlexMono.txt) |

- Шрифты подключаются **локально** (`@font-face`, как в [`reference/reference.css`](../../reference/reference.css)) и встраиваются в сборку exe. CDN и Google Fonts в рантайме не нужны, приложение работает офлайн.
- OFL разрешает встраивать и распространять шрифты вместе с приложением. Файл лицензии нужно положить рядом со шрифтами.
- Переменные: `--font-ui: "Manrope", "Segoe UI", sans-serif` и `--font-mono: "IBM Plex Mono", Consolas, monospace` (см. `tokens/tokens.css`).
