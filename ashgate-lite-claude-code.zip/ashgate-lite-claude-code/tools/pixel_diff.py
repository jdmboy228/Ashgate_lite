#!/usr/bin/env python3
"""Рендерит HTML-экраны в headless Chrome (2x) и сравнивает попиксельно с PNG из Figma.

Использование:
  python3 tools/pixel_diff.py                       # все экраны reference/screens, обе темы
  python3 tools/pixel_diff.py --html app/index.html?screen=b --frame b_glavnaya --theme dark
  python3 tools/pixel_diff.py --threshold 2.0 --tol-threshold 0.5   # пороги (по умолчанию 2.0 % и 0.5 %)
  python3 tools/pixel_diff.py --html http://localhost:8080/?screen=b --frame b_glavnaya --against reference

Эталон: design/frame-only/<theme>/<frame>.png (кадр без тени, 2x).
Метрики: diff — % пикселей, где max |ΔRGB| > 40 (после наложения на белый фон);
structural — то же, но с допуском сдвига ±1px (2x) — отсекает сглаживание шрифтов; mae — средняя ошибка.
Карта отличий: tools/out/<frame>_<theme>_diff.png. Нужны: Chrome/Chromium, Python 3 + Pillow + numpy.
"""
import argparse, glob, json, os, shutil, subprocess, sys, tempfile
from PIL import Image
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'tools/out')

def chrome():
    for c in [os.environ.get('CHROME'), 'google-chrome', 'chromium', 'chromium-browser', 'chrome',
              r'C:\Program Files\Google\Chrome\Application\chrome.exe', r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe']:
        if c and (shutil.which(c) or os.path.exists(c)): return shutil.which(c) or c
    sys.exit('Chrome/Chromium/Edge не найден: задайте переменную CHROME')

def render(url, w, h, out):
    prof = tempfile.mkdtemp()
    cmd = [chrome(), '--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-sandbox',
           '--force-device-scale-factor=2', f'--window-size={w},{h}', '--default-background-color=00000000',
           '--font-render-hinting=none', f'--screenshot={out}', url]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
    shutil.rmtree(prof, ignore_errors=True)

def flat(img):
    img = img.convert('RGBA'); bg = Image.new('RGBA', img.size, (255, 255, 255, 255))
    return np.asarray(Image.alpha_composite(bg, img).convert('RGB')).astype(np.int16)

def diff(a_path, b_path, name):
    a = Image.open(a_path); b = Image.open(b_path)
    if a.size != b.size: b = b.resize(a.size)  # размеры должны совпадать; если нет — сообщаем
    A, B = flat(a), flat(b)
    d = np.abs(A - B).max(axis=2)
    pct = float((d > 40).mean() * 100); mae = float(np.abs(A - B).mean())
    # «структурный» дифф: пиксель совпадает, если в окрестности 1px (2x) у рендера есть такой же — игнорирует сглаживание шрифтов
    best = d.copy()
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            best = np.minimum(best, np.abs(A - np.roll(np.roll(B, dy, 0), dx, 1)).max(axis=2))
    tol = float((best > 40).mean() * 100)
    vis = np.asarray(Image.open(a_path).convert('L').convert('RGB')).copy() // 3 + 170
    vis[d > 40] = [255, 0, 80]
    Image.fromarray(vis.astype(np.uint8)).save(os.path.join(OUT, name + '_diff.png'))
    return pct, tol, mae, a.size == Image.open(b_path).size

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--html'); ap.add_argument('--frame'); ap.add_argument('--theme')
    ap.add_argument('--threshold', type=float, default=2.0, help='макс. %% строгого диффа')
    ap.add_argument('--tol-threshold', type=float, default=0.5, help='макс. %% структурного диффа (±1px)')
    ap.add_argument('--against', choices=['png', 'reference'], default='png',
                    help='эталон: png (design/frame-only, по умолчанию) или reference (рендер reference/screens этим же браузером — '
                         'убирает разницу растеризации шрифтов между ОС, удобно на Windows)')
    a = ap.parse_args(); os.makedirs(OUT, exist_ok=True)
    jobs = []
    frames = [a.frame] if a.frame else [os.path.basename(p)[:-5] for p in sorted(glob.glob(os.path.join(ROOT, 'docs/layout/*.json')))]
    for fr in frames:
        L = json.load(open(os.path.join(ROOT, 'docs/layout', fr + '.json')))['root']
        for th in ([a.theme] if a.theme else ['light', 'dark']):
            src = a.html or os.path.join(ROOT, 'reference/screens', fr + '.html')
            url = src if src.startswith(('http:', 'https:', 'file:')) else 'file://' + os.path.abspath(src.split('?')[0]) + ('?' + src.split('?')[1] + '&' if '?' in src else '?')
            url += ('' if url.endswith(('?', '&')) else '&') + 'theme=' + th
            jobs.append((fr, th, url, L['width'], L['height']))
    res = []; bad = 0
    for fr, th, url, w, h in jobs:
        shot = os.path.join(OUT, f'{fr}_{th}.png'); render(url, int(w), int(h), shot)
        base = os.path.join(ROOT, 'design/frame-only', th, fr + '.png')
        if a.against == 'reference':
            base = os.path.join(OUT, f'{fr}_{th}_reference.png')
            render('file://' + os.path.join(ROOT, 'reference/screens', fr + '.html') + '?lock=0&theme=' + th, int(w), int(h), base)
        pct, tol, mae, same = diff(base, shot, f'{fr}_{th}')
        ok = pct <= a.threshold and tol <= a.tol_threshold and same; bad += not ok
        res.append({'frame': fr, 'theme': th, 'diffPercent': round(pct, 3), 'structuralDiffPercent': round(tol, 3), 'meanAbsError': round(mae, 3), 'sizeMatch': same, 'pass': ok})
        print(f'{"OK  " if ok else "FAIL"} {fr:24s} {th:5s} diff={pct:6.3f}%  structural={tol:6.3f}%  mae={mae:5.2f}' + ('' if same else '  (размер не совпал!)'))
    json.dump(res, open(os.path.join(OUT, 'report.json'), 'w'), ensure_ascii=False, indent=1)
    sys.exit(1 if bad else 0)
main()
