const ROOTS=__ROOTS__;
const coll=(await figma.variables.getLocalVariableCollectionsAsync()).find(c=>c.name==='Пульт · Тема');
const VN={};for(const id of coll.variableIds){const v=await figma.variables.getVariableByIdAsync(id);VN[id]=v.name.replace(/^color\//,'');}
const vn=b=>b?(VN[b.id]||('?'+b.id)):undefined;
const hx=c=>'#'+[c.r,c.g,c.b].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('').toUpperCase();
const r1=x=>Math.round(x*100)/100;
const paint=p=>{if(p.visible===false)return null;if(p.type==='SOLID'){let s=vn(p.boundVariables&&p.boundVariables.color)||hx(p.color);if(p.opacity!==undefined&&p.opacity<1)s+='@'+r1(p.opacity);return s;}if(p.type.startsWith('GRADIENT'))return{g:p.type,s:p.gradientStops.map(st=>[r1(st.position),vn(st.boundVariables&&st.boundVariables.color)||hx(st.color),r1(st.color.a)])};return p.type;};
const paints=a=>(a&&a!==figma.mixed&&a.length)?a.map(paint).filter(x=>x):undefined;
const ICT=new Set(['VECTOR','BOOLEAN_OPERATION','ELLIPSE','RECTANGLE','POLYGON','STAR','LINE','GROUP']);
const isIcon=n=>{if(!('children' in n))return false;if(!['INSTANCE','FRAME','COMPONENT','GROUP'].includes(n.type))return false;if(n.width>40||n.height>40)return false;if(n.layoutMode&&n.layoutMode!=='NONE')return false;const all=n.findAll(()=>true);return all.length>0&&all.every(k=>ICT.has(k.type)||(k.type==='FRAME'&&!(k.layoutMode&&k.layoutMode!=='NONE'))||k.type==='INSTANCE');};
const ICONS={};
const al=a=>({MIN:'start',MAX:'end',CENTER:'center',SPACE_BETWEEN:'between',BASELINE:'baseline'}[a]||a);
function dump(n,pb){const o={i:n.id,n:n.name,t:n.type};const bb=n.absoluteBoundingBox||{x:0,y:0,width:n.width,height:n.height};
 o.b=[r1(bb.x-pb.x),r1(bb.y-pb.y),r1(n.width),r1(n.height)];
 if(n.visible===false)o.hid=1;if('opacity' in n&&n.opacity<1)o.op=r1(n.opacity);if(n.rotation)o.rot=r1(n.rotation);
 const bv=n.boundVariables||{};
 if('layoutMode' in n&&n.layoutMode!=='NONE'){o.L={d:n.layoutMode[0],gap:n.primaryAxisAlignItems==='SPACE_BETWEEN'?'auto':n.itemSpacing,p:[n.paddingTop,n.paddingRight,n.paddingBottom,n.paddingLeft],ja:al(n.primaryAxisAlignItems),ca:al(n.counterAxisAlignItems)};if(n.layoutWrap==='WRAP')o.L.wrap=1;const tv={};for(const k of ['itemSpacing','paddingTop','paddingRight','paddingBottom','paddingLeft'])if(bv[k])tv[k]=vn(bv[k]);if(Object.keys(tv).length)o.L.tok=tv;}
 if('layoutSizingHorizontal' in n&&n.parent&&n.parent.type!=='PAGE'&&n.parent.type!=='SECTION'){o.sz=n.layoutSizingHorizontal[0]+n.layoutSizingVertical[0];if(n.layoutPositioning==='ABSOLUTE')o.abs=1;}
 if(n.minWidth)o.minW=n.minWidth;if(n.maxWidth)o.maxW=n.maxWidth;
 if('clipsContent' in n&&n.clipsContent)o.clip=1;
 const f=paints(n.fills);if(f&&n.type!=='TEXT')o.fill=f;
 const s=paints(n.strokes);if(s){o.st=s;o.sw=n.strokeWeight===figma.mixed?[n.strokeTopWeight,n.strokeRightWeight,n.strokeBottomWeight,n.strokeLeftWeight]:n.strokeWeight;if(n.strokeAlign!=='INSIDE')o.sa=n.strokeAlign;if(n.dashPattern&&n.dashPattern.length)o.dash=n.dashPattern;}
 if('effects' in n&&n.effects.length)o.fx=n.effects.filter(e=>e.visible!==false).map(e=>({t:e.type,c:e.color?(vn(e.boundVariables&&e.boundVariables.color)||hx(e.color)+'@'+r1(e.color.a)):undefined,x:e.offset&&e.offset.x,y:e.offset&&e.offset.y,r:e.radius,s:e.spread||undefined}));
 if('cornerRadius' in n){if(n.cornerRadius===figma.mixed)o.r=[n.topLeftRadius,n.topRightRadius,n.bottomRightRadius,n.bottomLeftRadius];else if(n.cornerRadius)o.r=n.cornerRadius;const rt=bv.topLeftRadius||bv.cornerRadius;if(rt)o.rTok=vn(rt);}
 if(n.type==='INSTANCE'){const mc=n.mainComponent;if(mc){o.mc=(mc.parent&&mc.parent.type==='COMPONENT_SET'?mc.parent.name+' / ':'')+mc.name;o.mcId=mc.id;}}
 if(n.type==='TEXT'){o.tx=n.characters;const segs=n.getStyledTextSegments(['fontName','fontSize','lineHeight','letterSpacing','fills','textDecoration']);const sg=segs.map(g=>({s:g.start,e:g.end,ff:g.fontName.family,fs:g.fontName.style,sz:g.fontSize,lh:g.lineHeight.unit==='AUTO'?'auto':(g.lineHeight.unit==='PIXELS'?g.lineHeight.value:g.lineHeight.value+'%'),ls:g.letterSpacing.value?(g.letterSpacing.unit==='PIXELS'?g.letterSpacing.value:g.letterSpacing.value+'%'):0,c:paints(g.fills)}));
  if(sg.length===1){const g=sg[0];delete g.s;delete g.e;o.font=g;}else o.segs=sg;o.ta=[n.textAlignHorizontal[0],n.textAlignVertical[0]];o.ar=n.textAutoResize;if(n.textTruncation==='ENDING')o.trunc=n.maxLines||1;else if(n.maxLines)o.maxLines=n.maxLines;return o;}
 if(isIcon(n)){const key=n.type==='INSTANCE'&&n.mainComponent?n.mainComponent.name:n.name;o.icon=key;const cols=[...new Set(n.findAll(k=>'fills' in k&&k.visible!==false).flatMap(k=>(paints(k.fills)||[]).concat(paints(k.strokes)||[])).filter(x=>typeof x==='string'))];o.iconColors=cols;if(!ICONS[key])ICONS[key]={id:n.id,mcId:o.mcId,w:n.width,h:n.height};return o;}
 if('children' in n&&n.children.length)o.k=n.children.map(c=>dump(c,bb));return o;}
const res={};for(const id of ROOTS){const n=await figma.getNodeByIdAsync(id);const bb=n.absoluteBoundingBox;res[id]=dump(n,bb);res[id].b=[0,0,n.width,n.height];}
return JSON.stringify({res,ICONS});
