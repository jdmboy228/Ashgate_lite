#!/usr/bin/env python3
"""Генерирует reference/screens/<frame>.html из docs/layout/<frame>.json + tokens/tokens.css.
Это эталонная статичная вёрстка 1:1 (не продакшн-код). Запуск: python3 tools/gen_reference.py"""
import json, os, re, html, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICON_CACHE = {}

def css_color(c):
    if c is None: return 'transparent'
    if 'token' in c:
        t = c['token']
        v = f"var(--{t.replace('/', '-')})" if t.startswith('color/') else f"var(--shadow-color-{t.split('/')[1]})"
    else: v = c['hex']
    if c.get('opacity') is not None and c['opacity'] < 1:
        v = f"color-mix(in srgb, {v} {round(c['opacity']*100,2)}%, transparent)"
    return v

def icon_svg(icon):
    f = icon['file']
    if f not in ICON_CACHE:
        s = open(os.path.join(ROOT, f)).read()
        s = re.sub(r'<\?xml[^>]*>', '', s).strip()
        if f.endswith('ashgate-logo.svg'):
            s = s.replace('fill="#3355FF"', 'style="fill:var(--color-accent)"').replace('fill="white"', 'style="fill:var(--color-onAccent)"').replace('fill="#FFFFFF"', 'style="fill:var(--color-onAccent)"')
        ICON_CACHE[f] = s
    return ICON_CACHE[f]

JUST = {'start': 'flex-start', 'center': 'center', 'end': 'flex-end', 'between': 'space-between', 'baseline': 'baseline'}

def stroke_in_layout(n):
    """Figma 'strokesIncludedInLayout' не выгружается напрямую — выводим из геометрии детей."""
    L = n.get('layout'); sw = n.get('strokeWeight')
    if not L or not n.get('strokes') or not n.get('children') or isinstance(sw, list): return False
    p = L['padding']
    for c in n['children']:
        if c.get('absolute') or c.get('hidden'): continue
        if L['direction'] == 'column':
            if c.get('sizing', {}).get('horizontal') == 'fill': return abs(c['x'] - (p['left'] + sw)) < 0.01
            if L['justify'] == 'start': return abs(c['y'] - (p['top'] + sw)) < 0.01
        else:
            if c.get('sizing', {}).get('vertical') == 'fill': return abs(c['y'] - (p['top'] + sw)) < 0.01
            if L['justify'] == 'start': return abs(c['x'] - (p['left'] + sw)) < 0.01
    return False

def node_html(n, parent=None, depth=0):
    st = ['box-sizing:border-box']
    pl = parent.get('layout') if parent else None
    flex_child = pl is not None and not n.get('absolute')
    sz = n.get('sizing', {'horizontal': 'fixed', 'vertical': 'fixed'})
    w, h = n['width'], n['height']
    is_text = n['type'] == 'TEXT'
    if parent is None:
        st += [f'width:{w}px', f'height:{h}px', 'position:relative']
    elif flex_child:
        prim, cnt = ('horizontal', 'vertical') if pl['direction'] == 'row' else ('vertical', 'horizontal')
        pw, ph = ('width', 'height') if pl['direction'] == 'row' else ('height', 'width')
        dim = {'horizontal': w, 'vertical': h}
        if sz[prim] == 'fixed': st += [f'{pw}:{dim[prim]}px', 'flex:none']
        elif sz[prim] == 'fill': st += ['flex:1 1 0', f'min-{pw}:0']
        else: st += ['flex:none']
        if sz[cnt] == 'fixed': st.append(f'{ph}:{dim[cnt]}px')
        elif sz[cnt] == 'fill': st.append('align-self:stretch')
        st.append('position:relative')
    else:
        st += ['position:absolute', f'left:{n["x"]}px', f'top:{n["y"]}px', f'width:{w}px', f'height:{h}px']
    if n.get('hidden'): st.append('display:none')
    if n.get('opacity') is not None: st.append(f'opacity:{n["opacity"]}')
    L = n.get('layout')
    if L and not is_text:
        st += ['display:flex', f'flex-direction:{L["direction"]}']
        p = dict(L['padding'])
        if stroke_in_layout(n):
            for k in p: p[k] += n['strokeWeight']
        st.append(f'padding:{p["top"]}px {p["right"]}px {p["bottom"]}px {p["left"]}px')
        if L['gap'] == 'auto': st.append('justify-content:space-between')
        else:
            st.append(f'justify-content:{JUST[L["justify"]]}')
            if L['gap']: st.append(f'gap:{L["gap"]}px')
        st.append(f'align-items:{JUST[L["align"]]}')
        if L.get('wrap'): st.append('flex-wrap:wrap')
    fills = n.get('fills')
    if fills and not is_text and 'icon' not in n:
        cols = [css_color(f) for f in fills if 'gradient' not in f]
        if len(cols) == 1: st.append(f'background:{cols[0]}')
        elif cols: st.append('background:' + ','.join(f'linear-gradient({c},{c})' for c in reversed(cols)))
    r = n.get('cornerRadius')
    if r:
        if n['type'] == 'ELLIPSE': pass
        elif isinstance(r, list): st.append('border-radius:' + ' '.join(f'{x}px' for x in r))
        else: st.append(f'border-radius:{r}px')
    if n['type'] == 'ELLIPSE': st.append('border-radius:50%')
    if n.get('effects'):
        sh = []
        for e in n['effects']:
            if e['type'] in ('DROP_SHADOW', 'INNER_SHADOW'):
                sh.append(('inset ' if e['type'] == 'INNER_SHADOW' else '') + f'{e["x"]}px {e["y"]}px {e["blur"]}px {e["spread"]}px {css_color(e["color"])}')
        if sh: st.append('box-shadow:' + ','.join(sh))
    if n.get('clipsContent') and not is_text: st.append('overflow:hidden')
    # stroke overlay
    inner = ''
    if n.get('strokes'):
        sw = n['strokeWeight']; al = n.get('strokeAlign', 'INSIDE')
        bw = ' '.join(f'{x}px' for x in sw) if isinstance(sw, list) else f'{sw}px'
        off = 0 if al == 'INSIDE' else (-(sw/2) if al == 'CENTER' else -sw) if not isinstance(sw, list) else 0
        style = 'dashed' if n.get('dashPattern') else 'solid'
        rad = 'inherit' if n['type'] != 'ELLIPSE' else '50%'
        if r and off and not isinstance(r, list): rad = f'{r - off}px'
        if n.get('dashPattern') and not isinstance(sw, list):
            rr = r if isinstance(r, (int, float)) else 0
            da = ' '.join(str(x) for x in n['dashPattern'])
            inner = (f'<svg class="stroke" style="inset:0" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect x="{sw/2}" y="{sw/2}" width="{w-sw}" height="{h-sw}" '
                     f'rx="{max(rr - sw/2, 0)}" fill="none" stroke-width="{sw}" stroke-dasharray="{da}" style="stroke:{css_color(n["strokes"][0])}"/></svg>')
        else:
            inner = f'<i class="stroke" style="inset:{off}px;border:{bw} {style} {css_color(n["strokes"][0])};border-radius:{rad}"></i>'
    attrs = f' data-name="{html.escape(n["name"])}" data-figma="{n["id"]}"'
    if not is_text and 'icon' not in n and sz.get('horizontal') == 'hug':
        st.append(f'--fw:{w}px'); attrs += ' class="hugf"'
    if is_text:
        t = n['text']
        def fs(f):
            lh = 'normal' if f['lineHeight'] == 'auto' else f'{f["lineHeight"]}px'
            fam = 'var(--font-mono)' if 'Mono' in f['fontFamily'] else 'var(--font-ui)'
            s = [f'font:{f["fontWeight"]} {f["fontSize"]}px/{lh} {fam}', f'color:{css_color(f["color"])}']
            if f['letterSpacing']: s.append(f'letter-spacing:{f["letterSpacing"]}px')
            return s
        if 'segments' in t:
            body = ''.join(f'<span style="{";".join(fs(s))}">{html.escape(t["content"][s["start"]:s["end"]])}</span>' for s in t['segments'])
            st += fs(t['segments'][0])
        else:
            body = html.escape(t['content']); st += fs(t)
        st.append(f'text-align:{t["textAlign"]}')
        st.append('white-space:pre' if t['autoResize'] == 'WIDTH_AND_HEIGHT' else 'white-space:pre-wrap')
        hug = t['autoResize'] == 'WIDTH_AND_HEIGHT'
        if hug: st.append(f'--fw:{w}px')
        if t.get('truncate'): st += ['white-space:pre', 'overflow:hidden', 'text-overflow:ellipsis']
        body = body.replace('\n', '<br>')
        return '  ' * depth + f'<div class="t{" hug" if hug else ""}"{attrs} style="{";".join(st)}">{body}</div>\n'
    if 'icon' in n:
        ic = n['icon']
        if ic.get('colorToken'): st.append(f'color:var(--{ic["colorToken"].replace("/", "-")})')
        if ic.get('themeSwap'):
            a = icon_svg({'file': ic['themeSwap']['light']}); b = icon_svg({'file': ic['themeSwap']['dark']})
            body = f'<span class="only-light">{a}</span><span class="only-dark">{b}</span>'
        else: body = icon_svg(ic)
        return '  ' * depth + f'<span class="ic"{attrs} style="{";".join(st)}">{body}</span>\n'
    kids = ''.join(node_html(c, n, depth + 1) for c in n.get('children', []))
    return '  ' * depth + f'<div{attrs} style="{";".join(st)}">\n{kids}{"  "*(depth+1)}{inner}\n' + '  ' * depth + '</div>\n'

HEAD = '''<!doctype html>
<html lang="ru" data-theme="light">
<head>
<meta charset="utf-8">
<title>{title}</title>
<link rel="stylesheet" href="../../tokens/tokens.css">
<link rel="stylesheet" href="../reference.css">
<script>(function(){{var q=new URLSearchParams(location.search),t=q.get('theme');if(t==='dark'||t==='light')document.documentElement.dataset.theme=t;if(q.get('lock')!=='0')document.documentElement.classList.add('lock-text');}})();</script>
</head>
<body>
'''

def main():
    out = os.path.join(ROOT, 'reference/screens'); os.makedirs(out, exist_ok=True)
    for f in sorted(glob.glob(os.path.join(ROOT, 'docs/layout/*.json'))):
        d = json.load(open(f))
        body = node_html(d['root'])
        open(os.path.join(out, d['frame'] + '.html'), 'w').write(HEAD.format(title=d['frame']) + body + '</body>\n</html>\n')
    cout = os.path.join(ROOT, 'reference/components'); os.makedirs(cout, exist_ok=True)
    for f in sorted(glob.glob(os.path.join(ROOT, 'docs/layout/components/*.json'))):
        d = json.load(open(f))
        open(os.path.join(cout, d['componentSet'] + '.html'), 'w').write(HEAD.format(title=d['componentSet']) + node_html(d['root']) + '</body>\n</html>\n')
    print('generated', len(glob.glob(os.path.join(out, '*.html'))), 'screens,', len(glob.glob(os.path.join(cout, '*.html'))), 'components')
main()
