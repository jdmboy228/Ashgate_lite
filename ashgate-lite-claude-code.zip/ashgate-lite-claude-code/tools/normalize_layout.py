#!/usr/bin/env python3
"""Превращает сырой дамп Figma (tools/figma/raw_dump.json, собран tools/figma/dump.js) в docs/layout/*.json.
Запуск: python3 tools/normalize_layout.py"""
import json, re, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
raw = json.load(open(os.path.join(ROOT, 'tools/figma/raw_dump.json')))
tok = json.load(open(os.path.join(ROOT, 'tokens/tokens.json')))
COLORS = tok['color']; SHADOWS = tok['shadowColor']
FRAMES = {
 '73:62': ('a_pervyj_zapusk', '73:2437'), '73:153': ('b_glavnaya', '73:2487'), '73:285': ('c_ves_trafik', '73:2522'),
 '73:407': ('d_vybor_proksi', '73:2566'), '73:616': ('e_upravlenie_proksi', '73:2623'), '73:742': ('f_poisk_prilozheniya', '73:2724'),
 '73:828': ('g_proksi_upal', '73:2787'), '73:952': ('h_kompakt_360x520', '73:2837'), '73:1058': ('i_proveryaem', '73:2871'),
 '73:1178': ('j_kompakt_ves_trafik', '73:2906'), '102:1591': ('k_redaktirovanie_proksi', '102:1722'),
 '101:1423': ('l_vyklyucheno', '101:1594')}
COMPS = {'73:1683': 'app_row', '73:1650': 'retry_button', '73:1687': 'footer_switch', '73:1488': 'proxy_menu_item',
 '73:1567': 'current_proxy_pill', '73:1469': 'proxy_dot', '73:1478': 'theme_toggle', '73:1450': 'app_icon', '73:1432': 'row_menu'}
WEIGHT = {'Regular': 400, 'Medium': 500, 'SemiBold': 600, 'Bold': 700, 'ExtraBold': 800}
SIZ = {'F': 'fixed', 'H': 'hug', 'L': 'fill'}

def icon_file(mc, iconname):
    nm = mc or iconname
    m = re.match(r'(.+?) / (?:Direction=(\w+), )?Size=(\d+), Theme=Regular', nm)
    if m: return m.group(1).lower().replace(' ', '-') + ('-' + m.group(2).lower() if m.group(2) else '') + '-' + m.group(3) + '.svg'
    if 'App=' in nm: return 'app-' + nm.split('App=')[1].lower().replace(' ', '-') + '.svg'
    if nm == 'Ashgate logo': return 'ashgate-logo.svg'
    if nm == 'app/dolphin': return 'app-dolphin-28.svg'
    return None

def color(p):
    if isinstance(p, dict): return {'gradient': p}
    s = p; op = None
    if '@' in s: s, op = s.split('@'); op = float(op)
    o = {}
    if s.startswith('#'): o['hex'] = s
    elif s.startswith('shadow/'): o['token'] = s; o['light'], o['dark'] = SHADOWS[s.split('/')[1]]
    else: o['token'] = 'color/' + s; o['light'], o['dark'] = COLORS[s]['light'], COLORS[s]['dark']
    if op is not None: o['opacity'] = op
    return o

def norm(n):
    x, y, w, h = n['b']
    o = {'id': n['i'], 'name': n['n'], 'type': n['t'], 'x': x, 'y': y, 'width': w, 'height': h}
    if n.get('hid'): o['hidden'] = True
    if 'op' in n: o['opacity'] = n['op']
    if 'rot' in n: o['rotation'] = n['rot']
    if 'L' in n:
        L = n['L']; o['layout'] = {'direction': 'row' if L['d'] == 'H' else 'column', 'gap': L['gap'],
            'padding': dict(zip(['top', 'right', 'bottom', 'left'], L['p'])), 'justify': L['ja'], 'align': L['ca']}
        if L.get('wrap'): o['layout']['wrap'] = True
        if L.get('tok'): o['layout']['tokens'] = L['tok']
    if 'sz' in n: o['sizing'] = {'horizontal': SIZ[n['sz'][0]], 'vertical': SIZ[n['sz'][1]]}
    if n.get('abs'): o['absolute'] = True
    if n.get('clip'): o['clipsContent'] = True
    if n.get('fill'): o['fills'] = [color(p) for p in n['fill']]
    if n.get('st'):
        o['strokes'] = [color(p) for p in n['st']]; o['strokeWeight'] = n['sw']; o['strokeAlign'] = n.get('sa', 'INSIDE')
        if n.get('dash'): o['dashPattern'] = n['dash']
    if n.get('fx'):
        o['effects'] = [{'type': e['t'], 'x': e.get('x'), 'y': e.get('y'), 'blur': e.get('r'), 'spread': e.get('s') or 0, 'color': color(e['c']) if e.get('c') else None} for e in n['fx']]
    if 'r' in n: o['cornerRadius'] = n['r']
    if 'rTok' in n: o['cornerRadiusToken'] = n['rTok']
    if 'mc' in n: o['component'] = n['mc']
    if n['t'] == 'TEXT':
        def fnt(f):
            return {'fontFamily': f['ff'], 'fontStyle': f['fs'], 'fontWeight': WEIGHT[f['fs']], 'fontSize': f['sz'],
                    'lineHeight': f['lh'], 'letterSpacing': f['ls'], 'color': color(f['c'][0]) if f.get('c') else None}
        t = {'content': n['tx']}
        if 'font' in n: t.update(fnt(n['font']))
        else: t['segments'] = [dict(start=s['s'], end=s['e'], **fnt(s)) for s in n['segs']]
        t['textAlign'] = {'L': 'left', 'C': 'center', 'R': 'right', 'J': 'justify'}[n['ta'][0]]
        t['verticalAlign'] = {'T': 'top', 'C': 'center', 'B': 'bottom'}[n['ta'][1]]
        t['autoResize'] = n['ar']
        if 'trunc' in n: t['maxLines'] = n['trunc']; t['truncate'] = 'ellipsis'
        o['text'] = t
    if 'icon' in n:
        cols = n.get('iconColors') or []
        tokc = [c for c in cols if not c.startswith('#')]
        o['icon'] = {'file': 'assets/icons/' + icon_file(n.get('mc'), n['icon']), 'figmaComponent': n.get('mc') or n['icon'],
                     'colorToken': ('color/' + tokc[0]) if len(tokc) == 1 else None, 'colors': cols}
        if o['icon']['file'].endswith('weather-moon-16.svg'):
            o['icon']['themeSwap'] = {'light': 'assets/icons/weather-moon-16.svg', 'dark': 'assets/icons/weather-sunny-16.svg'}
    if n.get('k'): o['children'] = [norm(k) for k in n['k']]
    return o

os.makedirs(os.path.join(ROOT, 'docs/layout/components'), exist_ok=True)
for fid, (slug, dark) in FRAMES.items():
    t = norm(raw['res'][fid])
    doc = {'frame': slug, 'figmaNodeLight': fid, 'figmaNodeDark': dark,
           'note': 'Координаты x/y — относительно родителя (px, 1x). Тёмная тема = та же структура, другие значения токенов (поле dark). Единственное структурное отличие: в Theme toggle иконка луны → солнце (icon.themeSwap).',
           'png': {'light': f'design/light/{slug}.png', 'dark': f'design/dark/{slug}.png'}, 'root': t}
    json.dump(doc, open(os.path.join(ROOT, f'docs/layout/{slug}.json'), 'w'), ensure_ascii=False, indent=1)
for cid, slug in COMPS.items():
    t = norm(raw['res'][cid])
    json.dump({'componentSet': slug, 'figmaNode': cid, 'root': t}, open(os.path.join(ROOT, f'docs/layout/components/{slug}.json'), 'w'), ensure_ascii=False, indent=1)
print('ok')
