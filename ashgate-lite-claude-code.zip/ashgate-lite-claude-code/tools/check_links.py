#!/usr/bin/env python3
"""Проверяет, что все относительные ссылки и пути в пакете существуют: md-ссылки, src/href в HTML, пути в layout JSON."""
import os, re, json, glob, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad, n = [], 0
def chk(base, p, src):
    global n
    p = p.split('#')[0].split('?')[0]
    if not p or re.match(r'^(https?:|mailto:|data:|file:)', p) or '${' in p: return
    n += 1
    if not os.path.exists(os.path.normpath(os.path.join(base, p))): bad.append(f'{src}: {p}')
for f in glob.glob(os.path.join(ROOT, '**/*.md'), recursive=True):
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'\]\(([^)\s]+)\)', t): chk(os.path.dirname(f), m.group(1), os.path.relpath(f, ROOT))
for f in glob.glob(os.path.join(ROOT, '**/*.html'), recursive=True) + glob.glob(os.path.join(ROOT, '**/*.css'), recursive=True):
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'(?:src|href)="([^"]+)"|url\("([^"]+)"\)', t): chk(os.path.dirname(f), m.group(1) or m.group(2), os.path.relpath(f, ROOT))
for f in glob.glob(os.path.join(ROOT, 'docs/layout/**/*.json'), recursive=True):
    d = json.load(open(f))
    for p in (d.get('png') or {}).values(): chk(ROOT, p, os.path.relpath(f, ROOT))
    def w(x):
        if 'icon' in x: chk(ROOT, x['icon']['file'], os.path.relpath(f, ROOT))
        for k in x.get('children', []): w(k)
    w(d['root'])
# пути в бэктиках в CLAUDE.md/README (только похожие на файлы пакета)
for f in ['CLAUDE.md', 'README.md']:
    for m in re.finditer(r'`((?:docs|tokens|reference|design|assets|tools)/[^`*<> ]+)`', open(os.path.join(ROOT, f)).read()):
        p = m.group(1).rstrip('/')
        if not any(c in p for c in '*<') and not p.startswith('design/lite-handoff'): chk(ROOT, p, f)
print(f'проверено ссылок: {n}, битых: {len(bad)}'); [print('  ', b) for b in bad]; sys.exit(1 if bad else 0)
