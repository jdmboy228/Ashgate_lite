#!/usr/bin/env python3
"""Печатает компактный markdown-конспект узла из docs/layout/*.json (для docs/*.md).
python3 tools/outline.py docs/layout/b_glavnaya.json [maxDepth]"""
import json, sys
def tok(c):
    if not c: return ''
    if 'token' in c: s = c['token'].replace('color/', '')
    else: s = c.get('hex', '?')
    return s + (f"@{c['opacity']}" if c.get('opacity') is not None else '')
def line(n):
    p = [f"**{n['name']}**", f"{n['width']:g}×{n['height']:g}", f"@({n['x']:g},{n['y']:g})"]
    s = n.get('sizing')
    if s: p.append(f"size {s['horizontal'][0].upper()}/{s['vertical'][0].upper()}")
    L = n.get('layout')
    if L:
        pd = L['padding']; pads = f"{pd['top']:g} {pd['right']:g} {pd['bottom']:g} {pd['left']:g}"
        p.append(f"{'row' if L['direction']=='row' else 'col'} gap {L['gap']} pad {pads} {L['justify']}/{L['align']}")
    if n.get('fills') and 'icon' not in n and n['type'] != 'TEXT': p.append('bg ' + ','.join(tok(c) for c in n['fills']))
    if n.get('strokes'): p.append(f"border {round(n["strokeWeight"],2) if not isinstance(n["strokeWeight"],list) else n["strokeWeight"]} {tok(n['strokes'][0])}" + (' dashed' if n.get('dashPattern') else ''))
    if n.get('cornerRadius'): p.append(f"r {n['cornerRadius']}")
    if n.get('effects'): p.append('shadow ' + ','.join(tok(e['color']) for e in n['effects'] if e.get('color')))
    if n.get('opacity') is not None: p.append(f"opacity {n['opacity']}")
    if n.get('hidden'): p.append('hidden')
    if n.get('absolute'): p.append('absolute')
    if n.get('component') and 'icon' not in n: p.append(f"⟨{n['component']}⟩")
    if 'icon' in n: p.append(f"icon `{n['icon']['file'].split('/')[-1]}` {(n['icon'].get('colorToken') or '').replace('color/','')}")
    if n.get('text'):
        t = n['text']; f = t if 'fontSize' in t else t['segments'][0]
        p.append(f"«{t['content']}» {f['fontFamily'].replace('IBM Plex Mono','Mono')} {f['fontWeight']} {f['fontSize']}/{f['lineHeight']} {tok(f['color'])}" + (f" {t['textAlign']}" if t['textAlign'] != 'left' else '') + (' 1 строка…' if t.get('truncate') else ''))
    return ' · '.join(p)
def walk(n, d, maxd, out):
    out.append('  ' * d + '- ' + line(n))
    if d < maxd and 'icon' not in n:
        for k in n.get('children', []): walk(k, d + 1, maxd, out)
def outline(node, maxd=99):
    out = []; walk(node, 0, maxd, out); return '\n'.join(out)
if __name__ == '__main__':
    d = json.load(open(sys.argv[1])); print(outline(d['root'], int(sys.argv[2]) if len(sys.argv) > 2 else 99))
