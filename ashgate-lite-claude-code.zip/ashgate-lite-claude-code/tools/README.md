# tools/

| Скрипт | Что делает |
|---|---|
| `pixel_diff.py` | Рендерит HTML в headless Chrome/Edge при 2x и сравнивает с `design/frame-only/<тема>/<экран>.png` (или с рендером reference: `--against reference`). Метрики: strict (% пикселей с max\|ΔRGB\| > 40), structural (то же с допуском сдвига ±1 px), MAE. Пороги по умолчанию 2.0 % / 0.5 %. Отчёт пишется в `out/report.json`, карты отличий — в `out/*_diff.png`. Код выхода 1, если что-то не прошло. |
| `normalize_layout.py` | Превращает `figma/raw_dump.json` в `docs/layout/*.json` и `docs/layout/components/*.json` (токены, иконки, sizing). |
| `gen_reference.py` | Генерирует `reference/screens/*.html` и `reference/components/*.html` из layout JSON. Правила отображения Figma → CSS описаны в CLAUDE.md. |
| `gen_docs.py` | Генерирует `docs/screens.md`, `docs/components.md`, `docs/copy.md`. |
| `outline.py` | Печатает конспект дерева: `python3 tools/outline.py docs/layout/b_glavnaya.json 3`. |
| `figma/dump.js` | Скрипт для Figma Plugin API (`use_figma`): обходит узлы (`__ROOTS__` — массив id) и возвращает компактный JSON. |
| `figma/raw_dump.json` | Сырой дамп, из которого собраны данные: 10 светлых кадров, 9 Component Set, переменные «Пульт · Тема». |

Зависимости: Python 3.9+, `pip install pillow numpy`, Chrome / Chromium / Edge (путь можно задать переменной `CHROME`).
